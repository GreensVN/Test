# -*- coding: utf-8 -*-
"""
logging_setup.py
-----------------
Thiết lập logging tập trung: ghi log vào file `logs/assistant.log` (xoay vòng
khi file quá lớn) để có thể xem lại lịch sử / debug lỗi sau này, mà KHÔNG làm
thay đổi trải nghiệm REPL tương tác (các dòng print() hiện có vẫn giữ nguyên
để phản hồi trực tiếp cho người dùng).

Dùng:
    from logging_setup import setup_logging
    setup_logging()          # gọi 1 lần duy nhất, ở đầu main.py

    import logging
    logger = logging.getLogger(__name__)
    logger.info("...")
"""

import logging
import logging.handlers
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
LOG_FILE = os.path.join(LOG_DIR, "assistant.log")

_configured = False


def setup_logging(level: int = logging.INFO, console_level: int = logging.WARNING) -> None:
    """Cấu hình root logger. An toàn khi gọi nhiều lần (chỉ áp dụng lần đầu)."""
    global _configured
    if _configured:
        return

    os.makedirs(LOG_DIR, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(level)

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8"
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)

    # Chỉ in ra console những cảnh báo/lỗi thật sự (INFO đã có print() riêng
    # trong main.py để giữ giao diện REPL gọn gàng)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(console_level)
    console_handler.setFormatter(fmt)
    root.addHandler(console_handler)

    _configured = True
