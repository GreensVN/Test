# -*- coding: utf-8 -*-
"""
lite_model.py  (MỚI ở bản v6)
-----------------------------
BỘ PHÂN LOẠI Ý ĐỊNH "NHẸ" - VIẾT HOÀN TOÀN BẰNG PYTHON THUẦN.
KHÔNG cần scikit-learn, KHÔNG cần numpy/scipy, KHÔNG cần joblib.

VÌ SAO CẦN FILE NÀY?
    Trước đây `intent_model.py` import scikit-learn ngay ở đầu file, nên chỉ
    cần MÁY CHƯA CÀI ĐƯỢC scikit-learn (rất hay gặp trên Windows 7 / Python
    3.8 vì thiếu Visual C++ Redistributable, hoặc máy không có mạng để pip
    install) là TOÀN BỘ chương trình sập ngay từ dòng import - không chạy
    được bất cứ tính năng nào, kể cả những tính năng không liên quan gì tới
    máy học.

    Từ bản v6, hệ thống có 3 tầng model, tự động chọn cái tốt nhất đang có:
        1. PhoBERT          (chính xác nhất, cần torch + transformers)
        2. TF-IDF sklearn   (tốt, cần scikit-learn)
        3. LiteIntentModel  (file này - luôn chạy được, 0 thư viện ngoài)

MÔ HÌNH DÙNG THUẬT TOÁN GÌ?
    Naive Bayes đa thức (Multinomial NB) trên đặc trưng nhị phân gồm:
        - từ đơn        ("w:chrome")
        - cặp từ liền kề ("b:mở chrome")
        - n-gram ký tự 3-4 trong từng từ ("c:chr") -> chịu được gõ sai chính tả
    Kèm HIỆU CHUẨN NHIỆT ĐỘ (temperature scaling) tự động: chia dữ liệu
    train/validation cố định, dò tìm nhiệt độ cho ra xác suất đáng tin nhất
    (tối thiểu hoá negative log-likelihood). Nhờ đó `confidence` trả về so
    sánh được với các ngưỡng trong config.json, thay vì luôn ~1.0 như Naive
    Bayes thô.

API TƯƠNG THÍCH scikit-learn (predict / predict_proba / classes_) nên
`intent_model.predict_intent()` dùng được ngay mà không cần rẽ nhánh.

Chạy thử:
    python lite_model.py
"""

import hashlib
import math
import os
import pickle

from text_utils import normalize_text

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LITE_MODEL_PATH = os.path.join(BASE_DIR, "lite_model.pkl")

# Tăng số này khi đổi cách sinh đặc trưng -> file cache cũ tự bị bỏ qua.
FORMAT_VERSION = 1

CHAR_NGRAM_SIZES = (3, 4)
TEMPERATURE_GRID = (0.02, 0.03, 0.05, 0.08, 0.12, 0.18, 0.25, 0.35, 0.5, 0.8)


# ============================================================================
# 1. SINH ĐẶC TRƯNG
# ============================================================================
def featurize(text):
    """Chuyển câu -> danh sách đặc trưng (đã khử trùng lặp, giữ thứ tự)."""
    cleaned = normalize_text(text or "")
    if not cleaned:
        return []

    words = cleaned.split()
    feats = []
    for word in words:
        feats.append("w:" + word)
        padded = " " + word + " "
        for size in CHAR_NGRAM_SIZES:
            if len(padded) >= size:
                for i in range(len(padded) - size + 1):
                    feats.append("c:" + padded[i:i + size])
    for i in range(len(words) - 1):
        feats.append("b:" + words[i] + " " + words[i + 1])

    return list(dict.fromkeys(feats))


# ============================================================================
# 2. MÔ HÌNH
# ============================================================================
class LiteIntentModel(object):
    """Naive Bayes đa thức thuần Python, API giống scikit-learn."""

    def __init__(self, alpha=0.15, temperature=0.08):
        self.alpha = alpha
        self.temperature = temperature
        self.classes_ = []
        self.fingerprint = None
        self.format_version = FORMAT_VERSION
        self._log_prior = {}
        self._log_prob = {}      # nhãn -> {đặc trưng: log P(f|c)}
        self._log_default = {}   # nhãn -> log P(đặc trưng chưa từng thấy|c)

    # -- huấn luyện --------------------------------------------------------
    def fit(self, texts, labels, calibrate=True):
        self._fit_counts(texts, labels)
        if calibrate:
            self.temperature = self._fit_temperature(texts, labels)
        return self

    def _fit_counts(self, texts, labels):
        counts = {}
        totals = {}
        docs = {}
        vocab = set()

        for text, label in zip(texts, labels):
            feats = featurize(text)
            if label not in counts:
                counts[label] = {}
                totals[label] = 0
                docs[label] = 0
            docs[label] += 1
            bucket = counts[label]
            for feat in feats:
                bucket[feat] = bucket.get(feat, 0) + 1
                vocab.add(feat)
            totals[label] += len(feats)

        n_docs = sum(docs.values()) or 1
        vocab_size = len(vocab) + 1
        alpha = self.alpha

        self.classes_ = sorted(counts)
        self._log_prior = {}
        self._log_prob = {}
        self._log_default = {}
        for label in self.classes_:
            denominator = totals[label] + alpha * vocab_size
            self._log_prior[label] = math.log(docs[label] / float(n_docs))
            self._log_default[label] = math.log(alpha / denominator)
            self._log_prob[label] = dict(
                (feat, math.log((count + alpha) / denominator))
                for feat, count in counts[label].items()
            )
        return self

    def _fit_temperature(self, texts, labels):
        """Dò nhiệt độ softmax trên tập validation tách cố định (mỗi mẫu thứ 7).

        Dùng một model "bóng" chỉ học 6/7 dữ liệu để hiệu chuẩn trên phần chưa
        thấy - nếu hiệu chuẩn ngay trên dữ liệu đã học, model sẽ luôn tự tin
        thái quá và mọi ngưỡng confidence đều mất tác dụng.
        """
        train_idx = [i for i in range(len(texts)) if i % 7 != 0]
        val_idx = [i for i in range(len(texts)) if i % 7 == 0]
        if not train_idx or not val_idx:
            return self.temperature

        shadow = LiteIntentModel(alpha=self.alpha)
        shadow._fit_counts([texts[i] for i in train_idx], [labels[i] for i in train_idx])
        if set(shadow.classes_) != set(self.classes_):
            return self.temperature

        cached = []
        for i in val_idx:
            cached.append((shadow._raw_scores(featurize(texts[i])), labels[i]))

        best_temp = self.temperature
        best_nll = float("inf")
        for temp in TEMPERATURE_GRID:
            nll = 0.0
            for scores, label in cached:
                prob = shadow._softmax(scores, temp).get(label, 1e-12)
                nll -= math.log(max(prob, 1e-12))
            if nll < best_nll:
                best_nll = nll
                best_temp = temp
        return best_temp

    # -- suy luận ----------------------------------------------------------
    def _raw_scores(self, feats):
        """log-likelihood TRUNG BÌNH trên mỗi đặc trưng (bất biến với độ dài câu)."""
        divisor = float(len(feats)) if feats else 1.0
        scores = {}
        for label in self.classes_:
            table = self._log_prob[label]
            default = self._log_default[label]
            total = self._log_prior[label]
            for feat in feats:
                total += table.get(feat, default)
            scores[label] = total / divisor
        return scores

    @staticmethod
    def _softmax(scores, temperature):
        temp = max(float(temperature), 1e-6)
        scaled = dict((label, value / temp) for label, value in scores.items())
        if not scaled:
            return {}
        top = max(scaled.values())
        exps = dict((label, math.exp(value - top)) for label, value in scaled.items())
        total = sum(exps.values()) or 1.0
        return dict((label, value / total) for label, value in exps.items())

    def predict_proba_dict(self, text):
        """Xác suất của TẤT CẢ nhãn cho 1 câu -> {nhãn: xác suất}."""
        if not self.classes_:
            return {}
        return self._softmax(self._raw_scores(featurize(text)), self.temperature)

    def predict_one(self, text):
        """Trả về (nhãn, độ tự tin) - giống API của PhoBertIntentClassifier."""
        probs = self.predict_proba_dict(text)
        if not probs:
            return "chitchat", 0.0
        label = max(probs, key=lambda key: probs[key])
        return label, probs[label]

    # -- API tương thích scikit-learn --------------------------------------
    def predict(self, texts):
        return [self.predict_one(text)[0] for text in texts]

    def predict_proba(self, texts):
        rows = []
        for text in texts:
            probs = self.predict_proba_dict(text)
            rows.append([probs.get(label, 0.0) for label in self.classes_])
        return rows

    def score(self, texts, labels):
        if not texts:
            return 0.0
        hit = sum(1 for text, label in zip(texts, labels) if self.predict_one(text)[0] == label)
        return hit / float(len(texts))

    # -- lưu / nạp ---------------------------------------------------------
    def to_state(self):
        return {
            "format_version": self.format_version,
            "alpha": self.alpha,
            "temperature": self.temperature,
            "classes": self.classes_,
            "fingerprint": self.fingerprint,
            "log_prior": self._log_prior,
            "log_prob": self._log_prob,
            "log_default": self._log_default,
        }

    @classmethod
    def from_state(cls, state):
        model = cls(alpha=state.get("alpha", 0.15),
                    temperature=state.get("temperature", 0.08))
        model.format_version = state.get("format_version", 0)
        model.classes_ = list(state.get("classes", []))
        model.fingerprint = state.get("fingerprint")
        model._log_prior = state.get("log_prior", {})
        model._log_prob = state.get("log_prob", {})
        model._log_default = state.get("log_default", {})
        return model


# ============================================================================
# 3. HUẤN LUYỆN / CACHE THEO "VÂN TAY" DỮ LIỆU
# ============================================================================
def dataset_fingerprint(texts, labels):
    """Vân tay của bộ dữ liệu - dùng để tự phát hiện model đã cũ.

    Trước đây model chỉ được huấn luyện lại khi người dùng XOÁ TAY file .pkl;
    sửa dataset.py xong mà quên xoá thì trợ lý vẫn chạy model cũ và người
    dùng tưởng dữ liệu mới "không có tác dụng".
    """
    digest = hashlib.sha1()
    digest.update(str(FORMAT_VERSION).encode("utf-8"))
    for text, label in zip(texts, labels):
        digest.update(text.encode("utf-8", "ignore"))
        digest.update(b"\x00")
        digest.update(label.encode("utf-8", "ignore"))
        digest.update(b"\x01")
    return digest.hexdigest()


def save_lite_model(model, path=LITE_MODEL_PATH):
    try:
        with open(path, "wb") as handle:
            pickle.dump(model.to_state(), handle, protocol=2)
    except OSError:
        return False
    return True


def load_lite_model(path=LITE_MODEL_PATH, fingerprint=None):
    """Nạp model đã cache. Trả về None nếu thiếu file / sai định dạng / đã cũ."""
    if not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as handle:
            state = pickle.load(handle)
    except Exception:
        return None
    if not isinstance(state, dict) or state.get("format_version") != FORMAT_VERSION:
        return None
    if fingerprint is not None and state.get("fingerprint") != fingerprint:
        return None
    model = LiteIntentModel.from_state(state)
    return model if model.classes_ else None


def train_lite_model(texts=None, labels=None, show_report=False):
    """Huấn luyện model nhẹ từ dataset.py (hoặc dữ liệu truyền vào)."""
    if texts is None or labels is None:
        from dataset import get_dataset_as_lists
        texts, labels = get_dataset_as_lists()

    model = LiteIntentModel().fit(texts, labels)
    model.fingerprint = dataset_fingerprint(texts, labels)

    if show_report:
        from platform_utils import safe_print
        holdout_x = [texts[i] for i in range(len(texts)) if i % 7 == 0]
        holdout_y = [labels[i] for i in range(len(labels)) if i % 7 == 0]
        safe_print("[MODEL NHẸ] {0} câu | {1} nhãn | nhiệt độ {2}".format(
            len(texts), len(model.classes_), model.temperature))
        safe_print("[MODEL NHẸ] Độ chính xác trên tập kiểm tra: {0:.1%}".format(
            model.score(holdout_x, holdout_y)))
    return model


def get_lite_model(path=LITE_MODEL_PATH, force_retrain=False):
    """Lấy model nhẹ: dùng cache nếu còn khớp dataset, ngược lại huấn luyện lại."""
    from dataset import get_dataset_as_lists
    texts, labels = get_dataset_as_lists()
    fingerprint = dataset_fingerprint(texts, labels)

    if not force_retrain:
        cached = load_lite_model(path, fingerprint=fingerprint)
        if cached is not None:
            return cached

    model = train_lite_model(texts, labels)
    save_lite_model(model, path)
    return model


# ============================================================================
# 4. CHẠY THỬ
# ============================================================================
if __name__ == "__main__":
    from platform_utils import safe_print, setup_console

    setup_console()
    lite = train_lite_model(show_report=True)
    safe_print("")
    for sample in [
        "Bật Google lên",
        "mo youtube nghe nhac di",
        "khởi chạy vs code giúp tôi",
        "tat may tinh di",
        "nhắc tôi họp lúc 3 giờ chiều",
        "15 cộng 27 bằng bao nhiêu",
        "xin chào bạn",
        "asdkjh qwe zxc khong lien quan gi ca",
    ]:
        intent, confidence = lite.predict_one(sample)
        safe_print("{0!r:44} -> {1:<14} ({2:.1%})".format(sample, intent, confidence))
