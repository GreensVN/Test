# -*- coding: utf-8 -*-
"""
platform_utils.py
------------------
TIỆN ÍCH PHÁT HIỆN HỆ ĐIỀU HÀNH + SỬA LỖI CONSOLE - MODULE MỚI (v3).

Vì sao cần module này (đặc biệt để hỗ trợ Windows 7):

  [LỖI SẬP CHƯƠNG TRÌNH]  Console mặc định trên Windows (nhất là Windows 7,
      cmd.exe dùng code page cũ như 850/1258 thay vì UTF-8) khiến print() một
      câu tiếng Việt có dấu có thể ném UnicodeEncodeError và LÀM SẬP chương
      trình ngay giữa phiên làm việc. Bản v2 chỉ hướng dẫn người dùng tự gõ
      `chcp 65001` trước khi chạy (dễ quên). setup_console() sửa tận gốc bằng
      cách tự ép stdout/stderr sang UTF-8 (không ném lỗi nếu gặp ký tự lạ) và
      tự đổi code page console - không cần người dùng làm gì thêm.

  [KHÁC BIỆT WINDOWS 7 vs 8/10/11]  Một số "app" trong app_map_windows (ví dụ
      "camera" -> "microsoft.windows.camera:") thực chất là ứng dụng kiểu Store
      App (UWP), CHỈ tồn tại từ Windows 8 trở lên. Windows 7 không có khái niệm
      này, mở sẽ chỉ ra lỗi "Windows không tìm thấy..." khó hiểu. windows_version()
      / is_windows7_or_older() giúp executor.py phát hiện và đưa ra lời giải
      thích rõ ràng thay vì lỗi hệ thống chung chung.

Toàn bộ hàm trong module này được viết bằng cú pháp Python 3.8 (không dùng
f-string lồng nhau, không dùng toán tử "|" cho type hint, không dùng
match-case...) để tương thích với Python 3.8 - phiên bản Python CUỐI CÙNG có
trình cài đặt chính thức hỗ trợ Windows 7 (xem HUONG_DAN_SU_DUNG.txt, mục
"HỖ TRỢ WINDOWS 7").
"""

import platform
import sys

SYSTEM = platform.system()  # "Windows" | "Darwin" | "Linux"

_console_ready = False


class _ResilientStream:
    """
    Bọc quanh sys.stdout / sys.stderr để KHÔNG BAO GIỜ ném lỗi khi ghi ra
    console - kể cả khi thao tác ghi đó do CHÍNH PYTHON tự gọi ngầm lúc
    chương trình thoát (đóng/flush stdout), một tình huống mà try/except
    trong code người dùng (kể cả safe_print()) KHÔNG với tới được vì nó nằm
    trong runtime C của Python, không chạy qua bất kỳ dòng code nào của bạn.

    Đây là lý do bạn từng thấy lỗi:
        Exception ignored in: <_io.TextIOWrapper name='<stdout>' ...>
        PermissionError: [WinError 31] A device attached to the system is
        not functioning
    xuất hiện dù đã dùng safe_print() ở khắp nơi - lỗi đó không xảy ra TRONG
    một lệnh print() cụ thể, mà xảy ra lúc Python tự đóng stdout khi tiến
    trình kết thúc, nên không lệnh try/except nào trong code có thể bắt được
    nó trừ khi ta bọc thẳng vào chính đối tượng stream.
    """

    def __init__(self, stream):
        self._stream = stream

    def write(self, s):
        # Thử ghi tối đa 3 lần, mỗi lần cách nhau 1 khoảng rất ngắn. Lý do:
        # WinError 31 ngay sau khi đổi code page thường là lỗi TẠM THỜI do
        # console Windows cần một khoảnh khắc để "ổn định" lại sau khi đổi
        # code page, không phải thiết bị hỏng vĩnh viễn - thử lại gần như
        # luôn thành công ngay ở lần 2.
        for attempt in range(3):
            try:
                self._stream.write(s)
                return len(s)
            except (OSError, ValueError):
                if attempt < 2:
                    try:
                        import time
                        time.sleep(0.02)
                    except Exception:
                        pass
                    continue
        # Vẫn lỗi sau 3 lần thử -> thử in bản KHÔNG DẤU (ít khả năng đụng
        # lỗi encode hơn), rồi mới chấp nhận bỏ qua dòng này.
        try:
            from text_utils import strip_diacritics
            ascii_s = strip_diacritics(s).encode("ascii", errors="replace").decode("ascii")
            self._stream.write(ascii_s)
        except Exception:
            pass  # Chấp nhận mất dòng này chứ tuyệt đối không làm sập chương trình
        return len(s)

    def flush(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def close(self):
        try:
            self._stream.close()
        except (OSError, ValueError):
            pass

    def isatty(self):
        try:
            return self._stream.isatty()
        except (OSError, ValueError):
            return False

    def __getattr__(self, name):
        # Uỷ quyền mọi thuộc tính/khác (encoding, buffer, fileno...) cho
        # stream gốc - chỉ ghi đè các thao tác ghi ở trên.
        return getattr(self._stream, name)


def setup_console():
    """
    Ép stdout/stderr in UTF-8 (thay ký tự lạ bằng dấu hỏi thay vì crash) và
    đổi code page console Windows sang 65001 (UTF-8). An toàn khi gọi nhiều
    lần hoặc khi stdout đã bị redirect ra file / pipe (vd trong unit test).

    NÊN gọi hàm này SỚM NHẤT có thể, trước bất kỳ print() nào - main.py gọi
    nó ngay dòng đầu của main().

    CÔNG TẮC THOÁT HIỂM: nếu máy bạn vẫn gặp lỗi console dù đã có mọi lớp
    phòng vệ ở trên (cực hiếm), đặt biến môi trường sau rồi chạy lại:
        set VIVOICE_NO_UTF8_CONSOLE=1
    để bỏ qua hẳn bước đổi code page - chữ có dấu có thể hiển thị sai
    (mất dấu / ký tự lạ) nhưng chương trình chắc chắn không bị sập.
    """
    global _console_ready
    if _console_ready:
        return
    _console_ready = True

    import os
    skip_cp_change = os.environ.get("VIVOICE_NO_UTF8_CONSOLE") == "1"
    force_cp_change = os.environ.get("VIVOICE_FORCE_UTF8_CONSOLE") == "1"

    # QUAN TRỌNG: SetConsoleOutputCP(65001) trên Windows 7 đã ghi nhận nhiều
    # trường hợp làm HỎNG VĨNH VIỄN khả năng ghi console cho cả phần còn lại
    # của phiên chạy (khác Windows 10/11 - ở đó lỗi chỉ tạm thời, thử lại là
    # qua). Hậu quả: chương trình không sập nhưng chạy "im lặng", gần như
    # không in được gì (kể cả bản không dấu dự phòng trong _ResilientStream,
    # vì handle console bị hỏng ở tầng hệ điều hành, không phải do encoding).
    # -> Windows 7 KHÔNG đổi mã trang console; chỉ thêm errors="replace" để
    # không crash. Đánh đổi: chữ có dấu có thể hiện sai/thành dấu hỏi trên
    # Windows 7, nhưng chương trình chắc chắn in được chữ và chạy được.
    # Người dùng có thể ép bật lại (chấp nhận rủi ro) bằng
    # VIVOICE_FORCE_UTF8_CONSOLE=1 - xem HUONG_DAN_SU_DUNG.txt mục VIII.3.
    # Nếu cả 2 biến cùng được đặt, VIVOICE_NO_UTF8_CONSOLE (an toàn) thắng.
    unstable_cp_change = skip_cp_change or (is_windows7_or_older() and not force_cp_change)

    for name in ("stdout", "stderr"):
        stream = getattr(sys, name)
        try:
            if unstable_cp_change:
                stream.reconfigure(errors="replace")
            else:
                stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            # AttributeError: stream không có reconfigure (vd bị thay bằng
            #   đối tượng giả trong test, hoặc Python < 3.7).
            # ValueError: stream đã đóng / không hỗ trợ đổi encoding.
            # Cả 2 trường hợp đều KHÔNG nên làm crash chương trình.
            pass
        # Bọc thêm 1 lớp chống lỗi - xem docstring _ResilientStream ở trên
        # để biết vì sao bước này BẮT BUỘC, không chỉ reconfigure() là đủ.
        setattr(sys, name, _ResilientStream(stream))

    if SYSTEM == "Windows" and not unstable_cp_change:
        try:
            import ctypes
            import time
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
            # Nghỉ rất ngắn để console "ổn định" lại ngay sau khi đổi code
            # page - đây chính là khoảnh khắc dễ ném WinError 31 nhất nếu
            # ghi ra console ngay lập tức.
            time.sleep(0.05)
        except Exception:
            # Một số môi trường hạn chế (chạy như service, console bị ẩn...)
            # không cho đổi code page - bỏ qua, không chặn chương trình ch��y.
            pass


def safe_print(text: str = "", end: str = "\n") -> None:
    """
    In một khối văn bản NHIỀU DÒNG ra console, chia theo từng dòng.

    LƯU Ý: tuyến phòng thủ CHÍNH chống lỗi console Windows (WinError 31,
    xem _ResilientStream ở trên) đã nằm trong chính sys.stdout/sys.stderr
    sau khi gọi setup_console() - nên kể cả print() thường giờ cũng an toàn.
    Hàm safe_print() này là lớp phòng vệ BỔ SUNG: in từng dòng riêng biệt
    (thay vì 1 khối dài) giúp nếu có dòng nào đó vẫn lỗi thì chỉ mất đúng
    dòng đó (tự động in lại bản không dấu) thay vì ảnh hưởng tới cả khối.
    """
    lines = text.split("\n")
    last_index = len(lines) - 1
    for i, line in enumerate(lines):
        # Dòng cuối cùng dùng `end` do người gọi chỉ định (mặc định "\n"),
        # các dòng ở giữa luôn xuống dòng bình thường.
        line_end = end if i == last_index else "\n"
        try:
            print(line, end=line_end)
        except (PermissionError, OSError):
            try:
                from text_utils import strip_diacritics
                print(strip_diacritics(line).encode("ascii", errors="replace").decode("ascii"),
                      end=line_end)
            except Exception:
                pass  # Bỏ qua dòng này chứ không làm sập cả chương trình


def windows_version():
    """
    Trả về (major, minor) phiên bản KERNEL Windows, vd (6, 1) cho Windows 7 SP1,
    (6, 2)/(6, 3) cho Windows 8/8.1, (10, 0) cho Windows 10 VÀ 11 (Windows 11
    vẫn báo kernel 10.0, phân biệt qua build number nếu cần).

    Trả về None nếu không phải Windows hoặc không xác định được (khi đó nên
    coi như "không chắc, cứ để hệ thống tự báo lỗi" thay vì đoán bừa).
    """
    if SYSTEM != "Windows":
        return None
    try:
        raw = platform.win32_ver()[1]  # vd "6.1.7601" (Windows 7 SP1)
        parts = raw.split(".")
        return int(parts[0]), int(parts[1])
    except (ValueError, IndexError, AttributeError):
        return None


def is_windows7_or_older():
    """True nếu đang chạy trên Windows 7 / Vista trở về trước (kernel <= 6.1)."""
    ver = windows_version()
    return ver is not None and ver <= (6, 1)


def windows_version_label():
    """Nhãn dễ đọc để in ra log/console, vd 'Windows 7', 'Windows 10'.

    v6.3: phân biệt Windows 11 - kernel vẫn báo 10.0 như Windows 10 nhưng có
    build number >= 22000.
    """
    ver = windows_version()
    if ver is None:
        return SYSTEM
    if ver == (10, 0):
        try:
            build = int(platform.win32_ver()[1].split(".")[2])
        except (ValueError, IndexError):
            build = 0
        return "Windows 11" if build >= 22000 else "Windows 10"
    labels = {
        (6, 0): "Windows Vista",
        (6, 1): "Windows 7",
        (6, 2): "Windows 8",
        (6, 3): "Windows 8.1",
    }
    return labels.get(ver, "Windows (kernel {}.{})".format(*ver))


# ============================================================================
# PHÁT HIỆN MÔI TRƯỜNG NÂNG CAO (v6.3): WSL, desktop Linux, công cụ có sẵn
# ============================================================================
def _read_osrelease() -> str:
    """Nội dung /proc/sys/kernel/osrelease (chuỗi rỗng nếu không đọc được)."""
    try:
        with open("/proc/sys/kernel/osrelease", "r", encoding="utf-8", errors="ignore") as f:
            return f.read()
    except OSError:
        return ""


def is_wsl() -> bool:
    """True nếu đang chạy trong WSL (Windows Subsystem for Linux).

    Vì sao cần biết: trên WSL, platform.system() trả về \"Linux\" nên nhánh
    Linux của executor.py được dùng - nhưng systemctl/pactl/xdg-open...
    thường KHÔNG hoạt động (không có systemd/máy chủ âm thanh/màn hình thật).
    Bù lại, WSL cho phép gọi thẳng phần thực thi của Windows host
    (shutdown.exe, powershell.exe, explorer.exe...) qua cơ chế interop, nên
    executor.py/tts.py có đường chuyển tiếp riêng khi phát hiện WSL.
    """
    if SYSTEM != "Linux":
        return False
    import os
    if os.environ.get("WSL_DISTRO_NAME") or os.environ.get("WSL_INTEROP"):
        return True
    return "microsoft" in _read_osrelease().lower()


def linux_desktop() -> str:
    """Tên môi trường desktop Linux đang dùng ('gnome', 'kde', 'xfce'...),
    hoặc chuỗi rỗng nếu không xác định được (server không GUI, WSL...)."""
    import os
    for var in ("XDG_CURRENT_DESKTOP", "DESKTOP_SESSION", "GDMSESSION"):
        value = os.environ.get(var, "")
        if value:
            # Giá trị có thể là danh sách kiểu "ubuntu:GNOME" - desktop THẬT
            # nằm ở thành phần CUỐI (thành phần đầu thường là tên session
            # của distro), nên lấy phần cuối sau dấu ':'.
            return value.split(":")[-1].strip().lower()
    return ""


def has_command(name) -> bool:
    """True nếu lệnh `name` có trong PATH (chỉ dò, không chạy thật)."""
    import shutil
    return shutil.which(name) is not None


def _module_available(module_name: str) -> bool:
    """True nếu import được module (chỉ dò, không import thật)."""
    import importlib.util
    try:
        return importlib.util.find_spec(module_name) is not None
    except (ImportError, ValueError):
        return False


def capability_report() -> dict:
    """Báo cáo tính năng nào của trợ lý sẽ chạy được trên MÁY HIỆN TẠI (v6.3).

    Trả về dict {"os", "os_label", "python", "is_wsl", "desktop", "features":
    {tên: {"ok": bool, "via": str}}}. Dùng cho cờ --sysinfo và lệnh
    \"he thong\" trong phiên, và để chẩn đoán khi người dùng báo lỗi.
    """
    features = {}

    def add(name, ok, via):
        features[name] = {"ok": bool(ok), "via": via}

    if SYSTEM == "Windows":
        add("open_website", True, "trình duyệt mặc định")
        add("open_app", True, "whitelist app_map_windows trong config.json")
        add("open_file", True, "os.startfile")
        add("shutdown/restart/logout", True, "shutdown.exe")
        add("lock", True, "rundll32 LockWorkStation")
        add("sleep", True, "rundll32 powrprof")
        add("volume", True,
            "pycaw (chính xác)" if _module_available("pycaw")
            else "phím ảo PowerShell - mute/unmute chỉ bật-tắt luân phiên "
                 "(pip install pycaw comtypes để chính xác)")
        add("screenshot", True, "PowerShell + System.Drawing")
        add("tts", True, "Windows SAPI" +
            (" + pyttsx3" if _module_available("pyttsx3") else ""))
    elif SYSTEM == "Darwin":
        add("open_website", True, "trình duyệt mặc định")
        add("open_app", True, "open -a (whitelist app_map_macos)")
        add("open_file", True, "open")
        add("shutdown/restart/logout/lock/sleep", True, "osascript / pmset")
        add("volume", True, "osascript output volume")
        add("screenshot", True, "screencapture")
        add("tts", True, "macOS say" +
            (" + pyttsx3" if _module_available("pyttsx3") else ""))
    elif is_wsl():
        add("open_website", has_command("wslview") or has_command("explorer.exe"),
            "wslview/explorer.exe -> trình duyệt của Windows host")
        add("open_app", True,
            "lệnh trong app_map_linux (app đồ hoạ cần WSLg trên Windows 11)")
        add("open_file", has_command("wslview"),
            "wslview (tự dịch đường dẫn Linux -> Windows; cài: sudo apt install wslu)")
        add("shutdown/restart/logout", has_command("shutdown.exe"),
            "shutdown.exe của Windows host")
        add("lock", has_command("rundll32.exe"), "rundll32 của Windows host")
        add("sleep", has_command("rundll32.exe"), "rundll32 powrprof của Windows host")
        add("volume", has_command("powershell.exe"),
            "phím ảo PowerShell của Windows host")
        add("screenshot", has_command("powershell.exe"),
            "PowerShell chụp màn hình Windows host")
        add("tts", has_command("powershell.exe") or _module_available("pyttsx3")
            or _module_available("gtts"),
            "SAPI của Windows host (qua powershell.exe) / pyttsx3 / gTTS")
    else:  # Linux thật (và các hệ Unix tương tự)
        add("open_website", has_command("xdg-open"), "xdg-open")
        add("open_app", True, "lệnh trong app_map_linux của config.json")
        add("open_file", has_command("xdg-open"), "xdg-open")
        add("shutdown/restart", has_command("systemctl") or has_command("shutdown"),
            "systemctl/shutdown")
        add("logout", has_command("loginctl") or has_command("gnome-session-quit"),
            "loginctl/gnome-session-quit")
        add("lock", any(has_command(c) for c in ("loginctl", "xdg-screensaver",
                        "gnome-screensaver-command", "qdbus", "dm-tool")),
            "loginctl / xdg-screensaver / gnome-screensaver / qdbus (KDE) / dm-tool")
        add("sleep", has_command("systemctl"), "systemctl suspend")
        add("volume", any(has_command(c) for c in ("wpctl", "pactl", "amixer")),
            "wpctl (PipeWire) / pactl (PulseAudio) / amixer (ALSA)")
        add("screenshot", any(has_command(c) for c in ("gnome-screenshot", "spectacle",
                              "scrot", "grim", "import")),
            "gnome-screenshot / spectacle (KDE) / scrot / grim (Wayland) / import (ImageMagick)")
        add("tts", _module_available("pyttsx3") or _module_available("gtts"),
            "pyttsx3 / gTTS (cần mạng)")

    add("stt_mic_online", _module_available("speech_recognition"),
        "SpeechRecognition + Google STT (cần mạng, cần pyaudio)")
    add("stt_offline", _module_available("torch") and _module_available("transformers"),
        "PhoWhisper offline (transformers + torch)")
    add("nlu_lite", True, "LiteIntentModel thuần Python (luôn chạy được)")
    add("nlu_tfidf", _module_available("sklearn"), "TF-IDF scikit-learn")
    add("nlu_phobert", _module_available("torch") and _module_available("transformers"),
        "PhoBERT (cần chạy train_phobert.py trước)")

    return {
        "os": SYSTEM,
        "os_label": windows_version_label(),
        "python": platform.python_version(),
        "is_wsl": is_wsl(),
        "desktop": linux_desktop() if SYSTEM == "Linux" and not is_wsl() else "",
        "features": features,
    }


def format_capability_report(report: dict) -> str:
    """Biến báo cáo từ capability_report() thành văn bản nhiều dòng dễ đọc."""
    lines = [
        "=" * 62,
        "BÁO CÁO KHẢ NĂNG CỦA MÁY (trợ lý ảo làm được gì trên máy này)",
        "=" * 62,
    ]
    os_line = report["os_label"]
    if report["is_wsl"]:
        os_line += " - trong WSL trên Windows"
    elif report.get("desktop"):
        os_line += " (desktop: %s)" % report["desktop"]
    lines.append("Hệ điều hành : %s" % os_line)
    lines.append("Python       : %s" % report["python"])
    lines.append("")
    lines.append("TÍNH NĂNG:")
    for name, info in report["features"].items():
        mark = "[OK]" if info["ok"] else "[--]"
        lines.append("  %-4s %-22s %s" % (mark, name, info["via"]))
    lines.append("")
    lines.append("Mục [--] là tính năng thiếu công cụ trên máy này - xem cách cài")
    lines.append("trong HUONG_DAN_SU_DUNG.txt (mục III và X).")
    return "\n".join(lines)


if __name__ == "__main__":
    setup_console()
    print("Hệ điều hành: {}".format(windows_version_label()))
    print("Windows 7 hoặc cũ hơn: {}".format(is_windows7_or_older()))
    print("WSL: {}".format(is_wsl()))
    safe_print(format_capability_report(capability_report()))
