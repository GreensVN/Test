# -*- coding: utf-8 -*-
"""
config.py
---------
Nạp cấu hình (WEBSITE_MAP, APP_MAP, FILE_MAP, ngưỡng độ tự tin...) từ file
`config.json` cạnh chương trình.

BẢN KẾT HỢP (v5): hợp nhất bản "v2 nhiều tính năng" (11 intent: web, app, file,
hệ thống, tìm kiếm, phát nhạc, nhắc nhở, thời tiết, giờ/ngày, tính toán, trò
chuyện) với bản "v4 bảo mật/đa nền tảng" (config.json tách riêng, whitelist
ứng dụng, hỗ trợ Windows 7). File config.json này CHỈ chứa những gì thật sự
cần cấu hình theo máy của bạn: 4/11 intent cần tra cứu bảng ánh xạ
(open_website, open_app, open_file, system_control). 7 intent còn lại
(search_web, play_media, set_reminder, get_weather, get_datetime, calculate,
chitchat) không cần cấu hình gì thêm, xem executor.py.

TẠI SAO TÁCH RA FILE JSON RIÊNG (thay vì để thẳng trong executor.py)?
  - Người dùng không rành Python vẫn chỉnh sửa được (chỉ là JSON đơn giản).
  - Không sợ gõ sai cú pháp Python làm hỏng cả chương trình.
  - Có thể có nhiều bộ cấu hình khác nhau và chọn khi chạy.

Nếu chưa có config.json, chương trình sẽ TỰ TẠO file với giá trị mặc định
(lấy từ DEFAULT_CONFIG bên dưới) để người dùng chỉnh sửa dần.
"""

import copy
import json
import os

from platform_utils import safe_print, setup_console

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")

DEFAULT_CONFIG = {
    # Ngưỡng độ tự tin tối thiểu để thực thi lệnh (0.0 - 1.0). Áp dụng cho
    # CẢ 11 intent khi gọi execute_command() trực tiếp (vd tích hợp STT
    # riêng). Nếu dùng nlu_advanced.NLU(), còn có thêm 2 ngưỡng riêng
    # (CONFIDENCE_ACCEPT / CONFIDENCE_ASK) tinh chỉnh trong nlu_advanced.py.
    "confidence_threshold": 0.35,

    # v6: 2 ngưỡng của tầng hiểu ý (nlu_advanced.py). Trước đây chúng bị VIẾT
    # CỨNG trong mã nguồn nên sửa config.json cũng không có tác dụng gì:
    #   >= confidence_accept : thực thi ngay
    #   >= confidence_ask    : hỏi lại cho chắc
    #   thấp hơn nữa         : báo "chưa hiểu"
    "confidence_accept": 0.45,
    "confidence_ask": 0.25,

    # Các hành động hệ thống cần hỏi xác nhận (y/n) trước khi chạy vì có
    # thể gây mất dữ liệu / gián đoạn công việc. Dùng chung bởi executor.py
    # (chặn thật) và nlu_advanced.py (đánh dấu need_confirm trước khi hỏi).
    "dangerous_actions": ["shutdown", "restart", "logout"],

    "website_map": {
        "google": "https://www.google.com",
        "google dich": "https://translate.google.com",
        "youtube": "https://www.youtube.com",
        "facebook": "https://www.facebook.com",
        "github": "https://github.com",
        "gmail": "https://mail.google.com",
        "drive": "https://drive.google.com",
        "notion": "https://www.notion.so",
        "chatgpt": "https://chat.openai.com",
        "tiki": "https://tiki.vn",
        "shopee": "https://shopee.vn",
        "lazada": "https://www.lazada.vn",
        "vnexpress": "https://vnexpress.net",
        "tuoi tre": "https://tuoitre.vn",
        "báo mới": "https://baomoi.com",
        "kenh14": "https://kenh14.vn",
        "zalo": "https://chat.zalo.me",
        "zalo web": "https://chat.zalo.me",
        "messenger": "https://www.messenger.com",
        "stackoverflow": "https://stackoverflow.com",
        "tiktok": "https://www.tiktok.com",
        "instagram": "https://www.instagram.com",
        "twitter": "https://twitter.com",
        "linkedin": "https://www.linkedin.com",
        "wikipedia": "https://vi.wikipedia.org",
        "coursera": "https://www.coursera.org",
        "udemy": "https://www.udemy.com",
    },

    # Ứng dụng trên Windows: CHỈ những app có trong danh sách này mới được
    # phép mở (whitelist) - xem lý do bảo mật trong executor.py
    "app_map_windows": {
        "chrome": "chrome.exe",
        "google chrome": "chrome.exe",
        "coc coc": "browser.exe",
        "cốc cốc": "browser.exe",
        "edge": "msedge.exe",
        "firefox": "firefox.exe",
        "notepad": "notepad.exe",
        "may tinh bo tui": "calc.exe",
        "máy tính bỏ túi": "calc.exe",
        "calculator": "calc.exe",
        "calc": "calc.exe",
        "paint": "mspaint.exe",
        "cmd": "cmd.exe",
        "dong lenh cmd": "cmd.exe",
        "dòng lệnh cmd": "cmd.exe",
        "powershell": "powershell.exe",
        "word": "winword.exe",
        "excel": "excel.exe",
        "powerpoint": "powerpnt.exe",
        "outlook": "outlook.exe",
        "vs code": "code",
        "vscode": "code",
        "visual studio code": "code",
        "visual studio": "devenv.exe",
        "explorer": "explorer.exe",
        "file explorer": "explorer.exe",
        "task manager": "taskmgr.exe",
        "discord": r"%LOCALAPPDATA%\Discord\Update.exe",
        "obs studio": r"%PROGRAMFILES%\obs-studio\bin\64bit\obs64.exe",
        "photoshop": r"%PROGRAMFILES%\Adobe\Adobe Photoshop\Photoshop.exe",
        "steam": r"%PROGRAMFILES(X86)%\Steam\Steam.exe",
        "unikey": "unikeynt.exe",
        # "camera" dùng URI kiểu Store App (UWP) - CHỈ có từ Windows 8 trở lên.
        # Trên Windows 7, executor.py sẽ tự phát hiện và từ chối kèm giải
        # thích thay vì báo lỗi hệ thống khó hiểu. Muốn dùng trên Windows 7,
        # hãy đổi sang phần mềm chụp ảnh webcam của bạn, ví dụ:
        #   "camera": r"%PROGRAMFILES%\ManufacturerCam\Cam.exe"
        "camera": "microsoft.windows.camera:",
        "zalo": r"%LOCALAPPDATA%\Programs\Zalo\Zalo.exe",
        "spotify": r"%APPDATA%\Spotify\Spotify.exe",
        "telegram": r"%APPDATA%\Telegram Desktop\Telegram.exe",
    },

    # Ứng dụng trên macOS: giá trị là tên app dùng với `open -a "<tên>"`.
    "app_map_macos": {
        "chrome": "Google Chrome",
        "google chrome": "Google Chrome",
        "safari": "Safari",
        "edge": "Microsoft Edge",
        "notepad": "TextEdit",
        "ghi chu": "Notes",
        "ghi chú": "Notes",
        "may tinh bo tui": "Calculator",
        "máy tính bỏ túi": "Calculator",
        "calculator": "Calculator",
        "calc": "Calculator",
        "paint": "Preview",
        "cmd": "Terminal",
        "dong lenh cmd": "Terminal",
        "dòng lệnh cmd": "Terminal",
        "terminal": "Terminal",
        "powershell": "Terminal",
        "word": "Microsoft Word",
        "excel": "Microsoft Excel",
        "powerpoint": "Microsoft PowerPoint",
        "outlook": "Microsoft Outlook",
        "vs code": "Visual Studio Code",
        "vscode": "Visual Studio Code",
        "visual studio code": "Visual Studio Code",
        "explorer": "Finder",
        "file explorer": "Finder",
        "task manager": "Activity Monitor",
        "discord": "Discord",
        "obs studio": "OBS",
        "photoshop": "Adobe Photoshop 2024",
        "steam": "Steam",
        "camera": "Photo Booth",
        "zalo": "Zalo",
        "spotify": "Spotify",
        "telegram": "Telegram",
        "nhac": "Music",
        "nhạc": "Music",
    },

    # Ứng dụng trên Linux: giá trị là LỆNH chạy trong PATH (có thể kèm tham
    # số, vd "libreoffice --writer").
    "app_map_linux": {
        "chrome": "google-chrome",
        "google chrome": "google-chrome",
        "firefox": "firefox",
        "edge": "microsoft-edge",
        "notepad": "gedit",
        "ghi chu": "gedit",
        "ghi chú": "gedit",
        "may tinh bo tui": "gnome-calculator",
        "máy tính bỏ túi": "gnome-calculator",
        "calculator": "gnome-calculator",
        "calc": "gnome-calculator",
        "paint": "gimp",
        "cmd": "gnome-terminal",
        "dong lenh cmd": "gnome-terminal",
        "dòng lệnh cmd": "gnome-terminal",
        "terminal": "gnome-terminal",
        "powershell": "gnome-terminal",
        "word": "libreoffice --writer",
        "excel": "libreoffice --calc",
        "powerpoint": "libreoffice --impress",
        "vs code": "code",
        "vscode": "code",
        "visual studio code": "code",
        "explorer": "nautilus",
        "file explorer": "nautilus",
        "task manager": "gnome-system-monitor",
        "discord": "discord",
        "obs studio": "obs",
        "steam": "steam",
        "camera": "cheese",
        "zalo": "zalo",
        "spotify": "spotify",
        "telegram": "telegram-desktop",
        "nhac": "rhythmbox",
        "nhạc": "rhythmbox",
    },

    # File mẫu - HÃY SỬA LẠI cho đúng máy bạn (trong config.json, không cần sửa code)
    "file_map": {
        "bao cao": "~/Documents/bao_cao.docx",
        "báo cáo": "~/Documents/bao_cao.docx",
        "bao cao thang": "~/Documents/bao_cao.docx",
        "báo cáo tháng": "~/Documents/bao_cao.docx",
        "bao cao tai chinh": "~/Documents/bao_cao_tai_chinh.xlsx",
        "báo cáo tài chính": "~/Documents/bao_cao_tai_chinh.xlsx",
        "tai lieu": "~/Documents",
        "tài liệu": "~/Documents",
        "tai lieu word": "~/Documents/tai_lieu.docx",
        "tài liệu word": "~/Documents/tai_lieu.docx",
        "huong dan": "~/Documents/huong_dan.pdf",
        "hướng dẫn": "~/Documents/huong_dan.pdf",
        "anh": "~/Pictures",
        "ảnh": "~/Pictures",
        "anh chup man hinh": "~/Pictures/Screenshots",
        "ảnh chụp màn hình": "~/Pictures/Screenshots",
        "hinh anh du lich": "~/Pictures",
        "hình ảnh du lịch": "~/Pictures",
        "excel doanh thu": "~/Documents/doanh_thu.xlsx",
        "pdf hop dong": "~/Documents/hop_dong.pdf",
        "pdf hợp đồng": "~/Documents/hop_dong.pdf",
        "hop dong": "~/Documents/hop_dong.pdf",
        "hợp đồng": "~/Documents/hop_dong.pdf",
        "thu muc tai xuong": "~/Downloads",
        "thư mục tải xuống": "~/Downloads",
        "tai xuong": "~/Downloads",
        "tải xuống": "~/Downloads",
        "ghi chu": "~/Documents/ghi_chu.txt",
        "ghi chú": "~/Documents/ghi_chu.txt",
        "danh sach sinh vien": "~/Documents/danh_sach_sinh_vien.xlsx",
        "danh sách sinh viên": "~/Documents/danh_sach_sinh_vien.xlsx",
        "luan van": "~/Documents/luan_van.docx",
        "luận văn": "~/Documents/luan_van.docx",
        "bai tap": "~/Documents/bai_tap.docx",
        "bài tập": "~/Documents/bai_tap.docx",
        "bang luong": "~/Documents/bang_luong.xlsx",
        "bảng lương": "~/Documents/bang_luong.xlsx",
        "ke hoach thang": "~/Documents/ke_hoach_thang.docx",
        "kế hoạch tháng": "~/Documents/ke_hoach_thang.docx",
        "ma nguon du an": "~/Projects",
        "mã nguồn dự án": "~/Projects",
        "hoa don": "~/Documents/hoa_don.pdf",
        "hoá đơn": "~/Documents/hoa_don.pdf",
        "nhac": "~/Music",
        "nhạc": "~/Music",
        "video quay man hinh": "~/Videos",
        "video quay màn hình": "~/Videos",
        "du lieu csv": "~/Documents/du_lieu.csv",
        "dữ liệu csv": "~/Documents/du_lieu.csv",
        "cv xin viec": "~/Documents/cv.pdf",
        "cv xin việc": "~/Documents/cv.pdf",
        "thu muc hinh anh": "~/Pictures",
        "thư mục hình ảnh": "~/Pictures",
        "file trinh chieu": "~/Documents/slide.pptx",
        "file trình chiếu": "~/Documents/slide.pptx",
        "slide thuyet trinh": "~/Documents/slide.pptx",
        "slide thuyết trình": "~/Documents/slide.pptx",
        "thu muc documents": "~/Documents",
        "thư mục documents": "~/Documents",
        "file backup": "~/Documents/backup",
    },
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Trộn 2 dict: giá trị trong `override` ưu tiên hơn `base` (đệ quy cho dict con)."""
    result = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config(path: str = CONFIG_PATH) -> dict:
    """
    Nạp config từ file JSON. Nếu chưa tồn tại, tự tạo file với giá trị mặc định.
    Nếu file tồn tại nhưng thiếu vài khoá, sẽ tự bổ sung từ DEFAULT_CONFIG
    (giúp người dùng nâng cấp không bị lỗi thiếu khoá).
    """
    if not os.path.exists(path):
        try:
            save_config(DEFAULT_CONFIG, path)
        except OSError as e:
            # Không để lỗi ghi file (thiếu quyền, ổ đĩa đầy...) chặn đứng
            # chương trình NGAY LẦN CHẠY ĐẦU TIÊN, trước khi làm được gì cả.
            # Chấp nhận chạy với cấu hình mặc định trong bộ nhớ, không lưu
            # ra file - người dùng vẫn dùng được, chỉ là lần sau lại phải
            # tạo lại (thà vậy còn hơn không chạy được).
            safe_print(f"[CẢNH BÁO] Không tạo được file cấu hình '{path}': {e}")
            safe_print("   Chương trình vẫn chạy tiếp với cấu hình mặc định (chưa lưu được ra file).")
        return copy.deepcopy(DEFAULT_CONFIG)

    try:
        with open(path, "r", encoding="utf-8") as f:
            user_config = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        raise RuntimeError(
            f"Không đọc được file cấu hình '{path}': {e}\n"
            f"-> Kiểm tra lại cú pháp JSON, hoặc xoá file để chương trình tạo lại mặc định."
        ) from e

    if not isinstance(user_config, dict):
        # JSON hợp lệ về CÚ PHÁP (vd chỉ có [] hoặc "chuỗi" ở gốc) nhưng sai
        # CẤU TRÚC (phải là object {..}) - không bắt ở đây thì _deep_merge()
        # bên dưới sẽ ném AttributeError khó hiểu khi gọi .items().
        raise RuntimeError(
            f"File cấu hình '{path}' phải có cấu trúc dạng {{...}} (JSON object), "
            f"nhưng đang là kiểu {type(user_config).__name__}.\n"
            f"-> Kiểm tra lại nội dung file, hoặc xoá để chương trình tạo lại mặc định."
        )

    return _deep_merge(DEFAULT_CONFIG, user_config)


def save_config(config: dict, path: str = CONFIG_PATH) -> None:
    """Lưu config xuống file JSON (định dạng đẹp, giữ nguyên chữ Unicode)."""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    setup_console()
    cfg = load_config()
    safe_print(f"Đã nạp cấu hình từ: {CONFIG_PATH}")
    safe_print(f"  - {len(cfg['website_map'])} trang web")
    safe_print(f"  - {len(cfg['app_map_windows'])} ứng dụng (Windows)")
    safe_print(f"  - {len(cfg['app_map_macos'])} ứng dụng (macOS)")
    safe_print(f"  - {len(cfg['app_map_linux'])} ứng dụng (Linux)")
    safe_print(f"  - {len(cfg['file_map'])} file/thư mục mẫu")
    safe_print(f"  - Ngưỡng độ tự tin: {cfg['confidence_threshold']}")
