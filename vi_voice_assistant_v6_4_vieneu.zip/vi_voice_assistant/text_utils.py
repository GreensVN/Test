# -*- coding: utf-8 -*-
"""
text_utils.py
-------------
Các hàm xử lý văn bản tiếng Việt dùng chung cho dataset.py, intent_model.py.

Tách riêng ra module này (thay vì để trong intent_model.py) để:
  - dataset.py có thể dùng để tự sinh biến thể "không dấu" mà không phải
    import ngược intent_model.py (tránh vòng lặp import).
  - Dễ viết unit test độc lập.
"""

import re
import unicodedata


def normalize_text(text: str) -> str:
    """Chuẩn hoá câu: chuyển thường, chuẩn Unicode NFC, bỏ ký tự thừa."""
    text = unicodedata.normalize("NFC", (text or "").strip().lower())
    text = re.sub(r"[^\w\s\.\-/:\\]", " ", text, flags=re.UNICODE)  # giữ ký tự đường dẫn
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def strip_diacritics(text: str) -> str:
    """
    Bỏ dấu tiếng Việt: 'bật google lên' -> 'bat google len'.

    Hữu ích để:
      - Sinh thêm dữ liệu huấn luyện (người dùng gõ tắt / STT không dấu
        vẫn được nhận diện đúng).
      - Làm phương án dự phòng khi so khớp thực thể (entity) không dấu
        với từ khoá có dấu trong config (WEBSITE_MAP, APP_MAP...).
    """
    text = unicodedata.normalize("NFD", text or "")
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Mn")
    text = text.replace("đ", "d").replace("Đ", "D")
    return unicodedata.normalize("NFC", text)


def normalize_no_diacritics(text: str) -> str:
    """normalize_text() rồi bỏ dấu -> dùng làm khoá so khớp 'khoan dung dấu'."""
    return strip_diacritics(normalize_text(text))
