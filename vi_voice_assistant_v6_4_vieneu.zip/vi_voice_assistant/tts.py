# -*- coding: utf-8 -*-
"""
tts.py
------
MÔ-ĐUN ĐỌC PHẢN HỒI BẰNG GIỌNG NÓI (Text-To-Speech) - TUỲ CHỌN.

Tự động chọn engine khả dụng theo thứ tự ưu tiên:
    0. Kho giọng đã tạo sẵn (python train_tts.py cache) - nhanh nhất, offline
    0. giọng AI VieNeu-TTS v3-Turbo - offline, TỰ NHIÊN NHẤT, thương mại
                        được (Apache 2.0), có nhân bản giọng tức thời
                        cài: pip install vieneu
                             python giong_noi_ai.py tai
    1. pyttsx3        - offline, không cần mạng (dự phòng)
                        cài: pip install pyttsx3
    2. Windows SAPI   - có sẵn trong Windows, không cần cài gì
    3. macOS `say`    - có sẵn trên macOS
    4. gTTS           - online, giọng tiếng Việt rất tự nhiên
                        cài: pip install gTTS playsound==1.2.2
    5. Chỉ in ra màn hình (nếu không có engine nào)

Dùng:
    from tts import speak
    speak("Đang mở Google cho bạn")

Nếu chưa cài engine nào, chương trình vẫn chạy bình thường (chỉ in chữ,
không đọc) - không bắt buộc phải cài để dùng phần lõi (hiểu ý + thực thi).
"""

import os
import platform
import subprocess
import tempfile
import threading
from platform_utils import safe_print, setup_console, is_wsl

SYSTEM = platform.system()

# Bật/tắt toàn bộ giọng nói (đổi thành False nếu chỉ muốn in chữ)
ENABLED = True

# Ưu tiên engine: "auto" | "pyttsx3" | "sapi" | "gtts" | "print"
ENGINE = "auto"

_engine_cache = None      # giữ instance pyttsx3 để không phải khởi tạo lại
_resolved_engine = None   # engine đã chọn sau lần đầu

# executor.py đặt nhắc nhở bằng threading.Timer (chạy trên LUỒNG NỀN riêng,
# xem _fire_reminder() trong executor.py) - nếu 1 nhắc nhở "chín" đúng lúc
# luồng chính cũng đang đọc phản hồi khác, cả 2 luồng có thể gọi speak()
# CÙNG LÚC. pyttsx3 không an toàn khi dùng đồng thời từ nhiều luồng (có thể
# treo hoặc lỗi khó chẩn đoán) - khoá này đảm bảo chỉ 1 luồng nói tại 1 thời
# điểm, luồng kia tự đợi tới lượt thay vì đụng độ.
_speak_lock = threading.Lock()


# ============================================================================
# 1. CÁC ENGINE CỤ THỂ
# ============================================================================
VOICE_CACHE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "voice_cache")
_voice_cache_index = None


def _load_voice_cache() -> dict:
    """Nạp kho giọng đã tạo sẵn bởi `python train_tts.py cache` (nếu có)."""
    global _voice_cache_index
    if _voice_cache_index is not None:
        return _voice_cache_index

    _voice_cache_index = {}
    index_path = os.path.join(VOICE_CACHE_DIR, "index.csv")
    if os.path.exists(index_path):
        import csv
        with open(index_path, encoding="utf-8-sig") as f:
            for row in csv.DictReader(f):
                key = (row.get("text") or "").strip().lower()
                fname = row.get("file")
                if key and fname:
                    _voice_cache_index[key] = os.path.join(VOICE_CACHE_DIR, fname)
    return _voice_cache_index


def _play_audio(path: str) -> bool:
    """
    Phát một file âm thanh. Ưu tiên `playsound` (nếu đã cài - xem hướng dẫn
    cài ở đầu file) vì nó CHẶN tới khi phát xong mới trả về, tránh 2 vấn đề
    của cách dự phòng bên dưới:
      1. Chồng tiếng nếu speak() được gọi liên tiếp nhanh (os.startfile trên
         Windows mở trình phát mặc định rồi trả về NGAY, không đợi phát xong).
      2. _speak_gtts() ghi đè file tạm cho lượt nói kế tiếp trong lúc file cũ
         có thể vẫn đang bị trình phát trước đó khoá -> PermissionError.
    """
    try:
        from playsound import playsound
        playsound(path)
        return True
    except ImportError:
        pass  # Chưa cài playsound -> dùng cách dự phòng theo hệ điều hành bên dưới
    except Exception:
        pass  # playsound có cài nhưng lỗi phát (thiếu codec...) -> vẫn thử cách dự phòng

    try:
        if SYSTEM == "Windows":
            os.startfile(path)
        elif SYSTEM == "Darwin":
            subprocess.run(["afplay", path], check=True)
        else:
            subprocess.run(["mpg123", "-q", path], check=True)
        return True
    except Exception:
        return False


def _speak_cache(text: str) -> bool:
    """Phát lại file giọng đã tạo sẵn -> nhanh nhất, không cần mạng."""
    path = _load_voice_cache().get(text.strip().lower())
    return _play_audio(path) if path and os.path.exists(path) else False


def _speak_piper(text: str) -> bool:
    """Đọc bằng giọng AI VieNeu-TTS v3-Turbo (offline, chất lượng cao nhất
    trong các engine ở đây). Model Apache 2.0 — thương mại được.

    Tên hàm giữ nguyên "_speak_piper" (lịch sử, trước đây gọi Piper) để
    không phải sửa lại bảng `order` bên dưới — logic bên trong đã đổi sang
    gọi giong_noi_ai.speak() với engine VieNeu.

    Trả về False (im lặng) nếu chưa cài gói vieneu — khi đó speak() tự rớt
    xuống pyttsx3 / SAPI như cũ.
    """
    try:
        import giong_noi_ai
    except Exception:
        return False
    try:
        if not giong_noi_ai.is_available():
            return False
        return giong_noi_ai.speak(text)
    except Exception:
        return False


def _speak_nc(text: str) -> bool:
    """Doc bang mo hinh tang NC (phi thuong mai, xem giong_nc.py).

    CO Y KHONG nam trong chuoi engine tu dong. Mac dinh phai la mo hinh
    thuong mai duoc, de nguoi fork repo nay khong vo tinh dinh giay phep
    phi thuong mai. Muon bat thi phai chu dong:

        import tts
        tts.ENGINE = "nc"

    hoac dat bien moi truong  TTS_ENGINE=nc

    Van tra ve False neu nguoi dung chua chay:
        python giong_nc.py dong-y mms-vie
    """
    try:
        import giong_nc
    except Exception:
        return False
    try:
        if not giong_nc.is_available():
            return False
        return giong_nc.speak(text)
    except Exception:
        return False


def _speak_pyttsx3(text: str) -> bool:
    """Đọc bằng pyttsx3 (offline). Ưu tiên chọn giọng tiếng Việt nếu máy có."""
    global _engine_cache
    try:
        import pyttsx3
        if _engine_cache is None:
            _engine_cache = pyttsx3.init()
            _engine_cache.setProperty("rate", 170)   # tốc độ đọc
            _engine_cache.setProperty("volume", 1.0)
            for voice in _engine_cache.getProperty("voices"):
                info = f"{voice.id} {getattr(voice, 'name', '')}".lower()
                if "vietnam" in info or "vi-vn" in info or "an" == getattr(voice, "name", "").lower():
                    _engine_cache.setProperty("voice", voice.id)
                    break
        _engine_cache.say(text)
        _engine_cache.runAndWait()
        return True
    except Exception:
        # Lỗi driver pyttsx3 (vd "run loop already started" - lỗi đã biết
        # trên Windows) có thể để engine ở trạng thái hỏng. Xoá cache để lần
        # gọi KẾ TIẾP thử khởi tạo engine MỚI thay vì kẹt vĩnh viễn với
        # instance hỏng cho cả phiên chạy (rớt xuống SAPI/gTTS mãi mãi dù
        # pyttsx3 có thể đã dùng lại được bình thường).
        _engine_cache = None
        return False


def _speak_sapi(text: str) -> bool:
    """Đọc bằng SAPI có sẵn trong Windows (không cần cài thư viện).

    v6.3: dùng được cả từ WSL - WSL cho phép gọi powershell.exe của Windows
    host qua cơ chế interop.
    """
    if SYSTEM == "Windows":
        exe = "powershell"
    elif SYSTEM == "Linux" and is_wsl():
        exe = "powershell.exe"
    else:
        return False
    try:
        safe = text.replace("'", "''")
        ps = (
            "Add-Type -AssemblyName System.Speech; "
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            f"$s.Speak('{safe}')"
        )
        subprocess.run([exe, "-NoProfile", "-Command", ps],
                       check=True, capture_output=True)
        return True
    except Exception:
        return False


def _speak_macos(text: str) -> bool:
    """Đọc bằng lệnh `say` có sẵn trên macOS."""
    if SYSTEM != "Darwin":
        return False
    try:
        subprocess.run(["say", text], check=True)
        return True
    except Exception:
        return False


def _speak_gtts(text: str) -> bool:
    """Đọc bằng Google TTS (cần internet, giọng tiếng Việt tự nhiên nhất)."""
    try:
        import uuid
        from gtts import gTTS
        # Tên file tạm RIÊNG BIỆT mỗi lần gọi (không ghi đè 1 file cố định) -
        # tránh xung đột khoá file với lượt phát trước đó, xem _play_audio().
        path = os.path.join(tempfile.gettempdir(), f"tro_ly_tts_{uuid.uuid4().hex}.mp3")
        gTTS(text=text, lang="vi").save(path)
        ok = _play_audio(path)
        try:
            os.remove(path)
        except OSError:
            pass  # File có thể vẫn đang phát (os.startfile không chờ) - bỏ qua, không phải lỗi nghiêm trọng
        return ok
    except Exception:
        return False


# ============================================================================
# 2. HÀM CHÍNH
# ============================================================================
def speak(text: str, show: bool = True) -> None:
    """
    Đọc `text` thành tiếng.

    show=True (mặc định) cũng in ra màn hình dạng "[TRỢ LÝ] ...". Đặt
    show=False khi caller (vd executor.respond()) đã tự in phản hồi rồi, để
    tránh in trùng 2 lần.

    Nếu không có engine nào hoạt động, chương trình vẫn chạy bình thường
    (chỉ in chữ nếu show=True, không báo lỗi).
    """
    global _resolved_engine

    if show:
        safe_print(f"[TRỢ LÝ] {text}")

    if not ENABLED:
        return

    # Câu đã có sẵn trong kho giọng thì phát ngay, khỏi tổng hợp lại. Đọc kho
    # giọng (chỉ đọc file, không đụng engine) nên KHÔNG cần giữ khoá.
    if _speak_cache(text):
        return

    order = {
        "piper": [_speak_piper],
        # Tang NC: phi thuong mai. Khong nam trong chuoi auto.
        "nc": [_speak_nc],
        "pyttsx3": [_speak_pyttsx3],
        "sapi": [_speak_sapi],
        "gtts": [_speak_gtts],
        "print": [],
    }.get(ENGINE)

    if order is None:  # ENGINE == "auto"
        if _resolved_engine is not None:
            order = [_resolved_engine]
        else:
            # VieNeu đứng đầu: giọng AI tự nhiên nhất, offline, thương mại OK.
            # Tự bỏ qua (trả False) nếu chưa cài → không ảnh hưởng ai cả.
            order = [_speak_piper, _speak_pyttsx3, _speak_sapi,
                     _speak_macos, _speak_gtts]

    # Giữ khoá trong lúc GỌI ENGINE THẬT (xem giải thích ở _speak_lock phía
    # trên) - tránh 2 luồng (luồng chính + luồng nhắc nhở nền) cùng gọi
    # pyttsx3/engine một lúc.
    with _speak_lock:
        for fn in order:
            if fn(text):
                _resolved_engine = fn
                return

        # v6.1: engine đã chọn từ trước giờ bị hỏng GIỮA PHIÊN (điển hình là
        # pyttsx3 lỗi "run loop already started"). Bản trước chỉ thử đúng 1
        # engine đã chọn rồi im lặng bỏ cuộc; giờ thử nốt các engine còn lại
        # và cập nhật lại lựa chọn (hoặc xoá nếu tất cả đều hỏng để lần sau
        # dò lại từ đầu).
        if ENGINE == "auto" and _resolved_engine is not None:
            broken = _resolved_engine
            for fn in (_speak_piper, _speak_pyttsx3, _speak_sapi,
                       _speak_macos, _speak_gtts):
                if fn is broken:
                    continue
                if fn(text):
                    _resolved_engine = fn
                    return
            _resolved_engine = None


def set_enabled(value: bool) -> None:
    """Bật / tắt giọng nói khi đang chạy."""
    global ENABLED
    ENABLED = value


def available_engines() -> list:
    """Liệt kê các engine đang có trên máy (để chẩn đoán)."""
    found = []
    try:
        import giong_noi_ai
        if giong_noi_ai.is_available():
            found.append("giọng AI VieNeu-TTS v3-Turbo (offline, Apache 2.0)")
    except Exception:
        pass
    try:
        import pyttsx3  # noqa: F401
        found.append("pyttsx3 (offline)")
    except ImportError:
        pass
    if SYSTEM == "Windows":
        found.append("Windows SAPI (có sẵn)")
    elif SYSTEM == "Linux" and is_wsl():
        found.append("Windows SAPI của host (qua WSL interop)")
    if SYSTEM == "Darwin":
        found.append("macOS say (có sẵn)")
    try:
        import gtts  # noqa: F401
        found.append("gTTS (cần internet)")
    except ImportError:
        pass
    if _load_voice_cache():
        found.insert(0, f"kho giọng sẵn ({len(_load_voice_cache())} câu)")
    return found or ["không có engine nào - sẽ chỉ in chữ"]


def is_available() -> bool:
    """
    True nếu có ÍT NHẤT 1 engine giọng nói khả dụng (kho giọng sẵn, pyttsx3,
    SAPI/say có sẵn theo hệ điều hành, hoặc gTTS). Dùng bởi main.py để báo
    cho người dùng biết cờ --speak / lệnh "voice" có tác dụng thật hay không.
    """
    if _load_voice_cache():
        return True
    try:
        import pyttsx3  # noqa: F401
        return True
    except ImportError:
        pass
    if SYSTEM in ("Windows", "Darwin"):
        return True
    # v6.3: trên WSL đọc được qua SAPI của Windows host (powershell.exe)
    if SYSTEM == "Linux" and is_wsl():
        return True
    try:
        import gtts  # noqa: F401
        return True
    except ImportError:
        pass
    return False


if __name__ == "__main__":
    setup_console()
    safe_print("Engine khả dụng trên máy này:")
    for e in available_engines():
        safe_print(f"  - {e}")
    safe_print()
    speak("Xin chào, tôi là trợ lý ảo tiếng Việt của bạn")
