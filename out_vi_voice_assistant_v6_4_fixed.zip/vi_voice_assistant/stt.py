# -*- coding: utf-8 -*-
"""
stt.py
------
MÔ-ĐUN NHẬN DIỆN GIỌNG NÓI (Speech-To-Text) - TUỲ CHỌN.

Cung cấp 2 cách dùng:

  1. NHANH, ĐƠN GIẢN (cờ --voice trong main.py):
        import stt
        if stt.is_available():
            text = stt.listen_once()

     Dùng SpeechRecognition (Google Web Speech API, cần internet) làm mặc
     định vì gọn nhẹ, không cần tải model. Đây CHỈ là lựa chọn nhanh để demo
     có tiếng nói thật.

  2. ĐẦY ĐỦ, OFFLINE (lệnh "mic" trong main.py, hoặc dùng trực tiếp):
        from stt import STT
        s = STT()                # tải model lần đầu (~1GB, cần mạng 1 lần)
        text = s.listen()        # bật mic, tự phát hiện im lặng để dừng
        safe_print(text)

     Dùng PhoWhisper (offline sau lần tải đầu, chính xác nhất cho tiếng
     Việt), tự động dự phòng sang Google STT nếu chưa cài torch/transformers.

Nếu bạn đã có pipeline STT riêng, bỏ qua module này và gọi thẳng
predict_intent(text_tu_stt_cua_ban) như HUONG_DAN_SU_DUNG.txt mô tả.

Cài đặt (tuỳ chọn):
    Cách 1 (khuyến nghị - chính xác nhất cho tiếng Việt, offline sau lần đầu):
        pip install transformers torch sounddevice
    Cách 2 (nhẹ hơn, cần internet mỗi lần nói):
        pip install SpeechRecognition sounddevice numpy

KHÔNG CẦN pyaudio. Cả hai chế độ đều thu âm bằng sounddevice (đóng gói sẵn
PortAudio). Nếu bạn gặp "Could not find PyAudio; check installation" nghĩa là
bạn đang dùng bản stt.py cũ - xem FIX_LOI_PIP_GIONG_NOI.txt.

Nếu chưa cài gì, chương trình vẫn chạy bình thường ở chế độ gõ phím.
"""

import io
import logging
import os
import wave
from platform_utils import safe_print, setup_console

logger = logging.getLogger(__name__)

# ============================================================================
# CÁC THAM SỐ CÓ THỂ CHỈNH (dùng bởi lớp STT - chế độ đầy đủ/offline)
# ============================================================================
MODEL_NAME = os.environ.get("STT_MODEL", "vinai/PhoWhisper-small")
SAMPLE_RATE = 16000          # Hz - Whisper cần 16kHz
SILENCE_THRESHOLD = 0.015    # RMS dưới mức này = im lặng
SILENCE_DURATION = 1.2       # giây im lặng liên tiếp -> kết thúc câu
MAX_DURATION = 15.0          # giây - giới hạn an toàn
CHUNK_DURATION = 0.1         # giây mỗi chunk thu âm


def _rms(chunk) -> float:
    """Tính RMS (độ lớn âm thanh) của một đoạn audio."""
    import numpy as np
    return float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2))) / 32768.0


# ============================================================================
# LỚP STT ĐẦY ĐỦ (PhoWhisper offline, dự phòng Google STT)
# ============================================================================
class STT:
    """
    Nhận diện giọng nói tiếng Việt dùng PhoWhisper (offline sau lần đầu).
    Dùng Google STT làm dự phòng khi không cài được transformers/torch.
    """

    def __init__(self, model_name: str = MODEL_NAME, device: str = "auto"):
        self.model_name = model_name
        self.device = device
        self._pipe = None           # transformers pipeline
        self._use_google = False    # fallback online
        self._sd = None             # sounddevice module
        self._recognizer = None     # speech_recognition.Recognizer (Google fallback)

    # ------------------------------------------------------------------
    def _load_model(self):
        """Tải PhoWhisper (ưu tiên) hoặc fallback sang Google STT."""
        if self._pipe is not None or self._use_google:
            return

        safe_print(f"[STT] Đang tải model {self.model_name} ...")
        safe_print("      (Lần đầu cần tải ~1GB, từ lần sau load offline <10 giây)")
        try:
            import torch
            from transformers import pipeline

            dev = self.device
            if dev == "auto":
                dev = "cuda" if torch.cuda.is_available() else "cpu"

            self._pipe = pipeline(
                "automatic-speech-recognition",
                model=self.model_name,
                device=dev,
                chunk_length_s=30,
                generate_kwargs={"language": "vi", "task": "transcribe"},
            )
            safe_print(f"[STT] Đã tải model ({dev.upper()}). Sẵn sàng nghe.")
        except Exception as e:
            safe_print(f"[STT] Không tải được PhoWhisper ({e})")
            safe_print("[STT] Thử dùng Google STT (cần internet mỗi lần nói)...")
            try:
                import speech_recognition  # noqa: F401
                self._use_google = True
                safe_print("[STT] Dùng Google STT làm dự phòng.")
            except ImportError as err:
                raise RuntimeError(
                    "Không có module nào cho STT.\n"
                    "Cài bằng:  pip install transformers torch sounddevice\n"
                    "hoặc:      pip install SpeechRecognition sounddevice"
                ) from err

    # ------------------------------------------------------------------
    def _record(self):
        """Ghi âm từ mic cho đến khi phát hiện im lặng dài. Trả về mảng numpy 16kHz int16."""
        import numpy as np
        if self._sd is None:
            import sounddevice as sd
            self._sd = sd

        sd = self._sd
        chunk_samples = int(SAMPLE_RATE * CHUNK_DURATION)
        silence_chunks = int(SILENCE_DURATION / CHUNK_DURATION)
        max_chunks = int(MAX_DURATION / CHUNK_DURATION)

        frames = []
        silent_count = 0
        speech_started = False

        safe_print("[MIC] Đang nghe... (nói xong im lặng ~1s là tự dừng)")

        with sd.InputStream(samplerate=SAMPLE_RATE, channels=1,
                            dtype="int16", blocksize=chunk_samples) as stream:
            for _ in range(max_chunks):
                chunk, _ = stream.read(chunk_samples)
                frames.append(chunk.copy())

                if _rms(chunk) > SILENCE_THRESHOLD:
                    speech_started = True
                    silent_count = 0
                else:
                    if speech_started:
                        silent_count += 1
                    if silent_count >= silence_chunks:
                        break

        audio = np.concatenate(frames, axis=0).flatten()
        safe_print(f"   Đã ghi {len(audio) / SAMPLE_RATE:.1f}s audio.")
        return audio

    # ------------------------------------------------------------------
    def transcribe_array(self, audio) -> str:
        """Nhận diện từ mảng numpy 16kHz int16."""
        import numpy as np
        self._load_model()

        if self._use_google:
            return self._google_from_array(audio)

        audio_float = audio.astype(np.float32) / 32768.0
        result = self._pipe({"sampling_rate": SAMPLE_RATE, "raw": audio_float})
        return (result.get("text") or "").strip()

    def transcribe_file(self, path: str) -> str:
        """Nhận diện từ file WAV/MP3."""
        self._load_model()
        if self._use_google:
            return self._google_from_file(path)
        result = self._pipe(path)
        return (result.get("text") or "").strip()

    def listen(self) -> str:
        """Thu âm từ mic rồi trả về text. Đây là hàm chính bạn gọi."""
        audio = self._record()
        text = self.transcribe_array(audio)
        safe_print(f"   Nhận diện: {text!r}")
        return text

    # ------------------------------------------------------------------
    def _google_from_array(self, audio) -> str:
        import speech_recognition as sr
        if self._recognizer is None:
            self._recognizer = sr.Recognizer()

        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)      # int16 = 2 bytes
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(audio.tobytes())
        buf.seek(0)

        with sr.AudioFile(buf) as source:
            audio_data = self._recognizer.record(source)
        try:
            return self._recognizer.recognize_google(audio_data, language="vi-VN")
        except Exception:
            return ""

    def _google_from_file(self, path: str) -> str:
        import speech_recognition as sr
        if self._recognizer is None:
            self._recognizer = sr.Recognizer()
        with sr.AudioFile(path) as source:
            audio_data = self._recognizer.record(source)
        try:
            return self._recognizer.recognize_google(audio_data, language="vi-VN")
        except Exception:
            return ""


# ============================================================================
# HÀM TIỆN ÍCH ĐƠN GIẢN (dùng bởi cờ --voice trong main.py)
# ============================================================================
try:
    import speech_recognition as _sr
    _SR_AVAILABLE = True
except ImportError:
    _SR_AVAILABLE = False

try:
    import sounddevice as _sd
    _SD_AVAILABLE = True
except Exception:
    # Exception chứ không phải ImportError: sounddevice có thể ném OSError khi
    # không nạp được thư viện PortAudio đi kèm.
    _SD_AVAILABLE = False


def has_pyaudio() -> bool:
    """True nếu máy có PyAudio (không bắt buộc - xem _record_audiodata_sd)."""
    try:
        import pyaudio  # noqa: F401
        return True
    except Exception:
        return False


def is_available() -> bool:
    """True nếu có ít nhất 1 phương án STT khả dụng.

    Cần MỘT trong hai bộ:
      - SpeechRecognition (giải mã) + sounddevice HOẬC pyaudio (thu âm)
      - transformers + torch (PhoWhisper) + sounddevice
    """
    if _SR_AVAILABLE and (_SD_AVAILABLE or has_pyaudio()):
        return True
    try:
        import torch  # noqa: F401
        import transformers  # noqa: F401
        return _SD_AVAILABLE
    except ImportError:
        return False


def _record_audiodata_sd(timeout: float = 6.0, phrase_limit: float = 8.0):
    """
    Thu âm từ micro bằng sounddevice rồi đóng gói thành sr.AudioData để
    SpeechRecognition giải mã. ĐÂY LÀ CÁCH THAY THẾ sr.Microphone() -
    sr.Microphone() bắt buộc phải có PyAudio, còn hàm này thì không.

    Tự dừng khi im lặng ≈ SILENCE_DURATION giây sau khi đã có tiếng nói.
    Trả về None nếu hết `timeout` mà không nghe thấy gì.
    """
    import numpy as np

    chunk_samples = int(SAMPLE_RATE * CHUNK_DURATION)
    silence_chunks = int(SILENCE_DURATION / CHUNK_DURATION)
    timeout_chunks = int(timeout / CHUNK_DURATION)
    max_chunks = int(min(MAX_DURATION, phrase_limit + timeout) / CHUNK_DURATION)

    frames = []
    silent_count = 0
    speech_started = False

    safe_print("[STT] Đang nghe... (nói vào micro, im lặng ~1s là tự dừng)")

    with _sd.InputStream(samplerate=SAMPLE_RATE, channels=1,
                         dtype="int16", blocksize=chunk_samples) as stream:
        for i in range(max_chunks):
            chunk, _overflow = stream.read(chunk_samples)
            if _rms(chunk) > SILENCE_THRESHOLD:
                speech_started = True
                silent_count = 0
            else:
                if speech_started:
                    silent_count += 1
                elif i >= timeout_chunks:
                    # Hết thời gian chờ mà chưa ai nói gì
                    return None
            if speech_started:
                frames.append(chunk.copy())
            if speech_started and silent_count >= silence_chunks:
                break

    if not frames:
        return None

    audio = np.concatenate(frames, axis=0).flatten()
    safe_print("   Đã ghi %.1fs audio." % (len(audio) / SAMPLE_RATE))

    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)          # int16
        wf.setframerate(SAMPLE_RATE)
        wf.writeframes(audio.tobytes())
    return _sr.AudioData(buf.getvalue()[44:], SAMPLE_RATE, 2)


def listen_once(language: str = "vi-VN", timeout: float = 6.0) -> str:
    """
    Ghi âm 1 lượt từ micro mặc định và trả về văn bản nhận diện được - dùng
    SpeechRecognition (Google Web Speech API, cần internet) nếu có sẵn vì
    nhẹ và không cần tải model; nếu không, dùng lớp STT (PhoWhisper) làm dự
    phòng. Trả về chuỗi rỗng "" nếu không nghe được / không có micro / lỗi.
    """
    if not is_available():
        if _SR_AVAILABLE:
            safe_print("[STT] Đã có SpeechRecognition nhưng thiếu thư viện thu âm.")
            safe_print("      Cài bằng:  pip install sounddevice numpy")
        else:
            safe_print("[STT] Chưa cài thư viện nhận diện giọng nói "
                       "-> dùng chế độ gõ phím.")
            safe_print("      Cài bằng:  pip install SpeechRecognition sounddevice numpy")
        return ""

    if _SR_AVAILABLE:
        recognizer = _sr.Recognizer()
        audio = None

        # --- CÁCH 1 (ƯU TIÊN): sounddevice - KHÔNG CẦN PyAudio ---------------
        if _SD_AVAILABLE:
            try:
                audio = _record_audiodata_sd(timeout=timeout, phrase_limit=8.0)
                if audio is None:
                    safe_print("[STT] Không nghe thấy gì trong "
                               "%.0fs, quay về gõ tay." % timeout)
                    return ""
            except Exception as e:
                safe_print(f"[STT] Thu âm bằng sounddevice lỗi: {e}")
                logger.warning("sounddevice lỗi: %s", e)
                audio = None

        # --- CÁCH 2 (DỰ PHÒNG): sr.Microphone() - cần PyAudio -------------
        if audio is None:
            try:
                with _sr.Microphone() as source:
                    safe_print("[STT] Đang nghe... (nói vào micro)")
                    recognizer.adjust_for_ambient_noise(source, duration=0.4)
                    audio = recognizer.listen(source, timeout=timeout,
                                              phrase_time_limit=8)
            except AttributeError as e:
                # "Could not find PyAudio; check installation" đi qua nhánh này
                safe_print(f"[STT] Không thu âm được: {e}")
                safe_print("      KHẮC PHỤC:  pip install sounddevice numpy")
                safe_print("      (không cần pyaudio - xem FIX_LOI_PIP_GIONG_NOI.txt)")
                logger.warning("Thiếu backend thu âm: %s", e)
                return ""
            except OSError as e:
                safe_print(f"[STT] Không tìm thấy micro: {e}")
                logger.warning("Không tìm thấy micro: %s", e)
                return ""
            except Exception as e:
                msg = str(e)
                if "PyAudio" in msg:
                    safe_print("[STT] Thiếu PyAudio — nhưng dự án này KHÔNG cần nó.")
                    safe_print("      KHẮC PHỤC:  pip install sounddevice numpy")
                else:
                    safe_print(f"[STT] Lỗi khi ghi âm: {msg}")
                logger.warning("Lỗi khi ghi âm: %s", msg)
                return ""

        try:
            text = recognizer.recognize_google(audio, language=language)
            safe_print(f"[STT] Nhận diện được: {text}")
            return text
        except _sr.UnknownValueError:
            safe_print("[STT] Không nghe rõ, bạn thử nói lại nhé.")
            return ""
        except _sr.RequestError as e:
            safe_print(f"[STT] Lỗi kết nối dịch vụ nhận diện giọng nói: {e}")
            logger.warning("Lỗi kết nối dịch vụ STT: %s", e)
            return ""

    # Dự phòng: dùng lớp STT đầy đủ (PhoWhisper) nếu SpeechRecognition không có
    try:
        return _default_stt().listen()
    except Exception as e:
        safe_print(f"[STT] Lỗi: {e}")
        return ""


_default_instance = None


def _default_stt() -> "STT":
    global _default_instance
    if _default_instance is None:
        _default_instance = STT()
    return _default_instance


# ============================================================================
# KIỂM TRA NHANH
# ============================================================================
if __name__ == "__main__":
    setup_console()
    safe_print("[STT] Kiểm tra module nhận diện giọng nói")
    safe_print(f"      Model mặc định (chế độ đầy đủ): {MODEL_NAME}")
    safe_print(f"      Sample rate    : {SAMPLE_RATE} Hz")
    safe_print(f"      Khả dụng (is_available): {is_available()}")
    safe_print()

    try:
        import sounddevice as sd
        devices = sd.query_devices()
        safe_print("Thiết bị âm thanh:")
        for i, d in enumerate(devices):
            if d["max_input_channels"] > 0:
                safe_print(f"  [{i}] {d['name']} (in: {d['max_input_channels']} channels)")
    except ImportError:
        safe_print("Chưa cài sounddevice:  pip install sounddevice")
        safe_print("Chế độ 'mic' đầy đủ (lớp STT) sẽ không dùng được, nhưng --voice "
              "(SpeechRecognition) vẫn có thể hoạt động nếu đã cài pyaudio.")
