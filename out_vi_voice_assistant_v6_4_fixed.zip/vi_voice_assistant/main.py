# -*- coding: utf-8 -*-
"""
main.py
-------
CHƯƠNG TRÌNH TRỢ LÝ ẢO HOÀN CHỈNH (BẢN KẾT HỢP v5)

Luồng xử lý:
    [Chế độ MIC]  Mic ghi âm -> STT -> text
    [Chế độ TAY]  Bạn gõ bàn phím -> text
                       |
              nlu_advanced.py  (chuẩn hoá, tách nhiều lệnh, ngữ cảnh, ngưỡng)
                       |
              intent_model.py  (phân loại + trích xuất thực thể)
                       |
              executor.py      (thực thi trên máy - có whitelist bảo mật)
                       |
              tts.py           (đọc phản hồi bằng giọng nói, nếu bật)

Cách chạy:
    python main.py                   # gõ bàn phím (mặc định, không cần cài thêm)
    python main.py --dry-run         # chỉ phân tích, không thực thi (an toàn khi test)
    python main.py --speak           # đọc phản hồi bằng giọng nói (cần pyttsx3/gTTS)
    python main.py --voice           # nhận lệnh qua micro (cần SpeechRecognition)
    python main.py --voice --speak   # hội thoại 2 chiều bằng giọng nói
"""

import argparse
import json
import logging
import sys

from platform_utils import safe_print, setup_console

# Gọi NGAY từ đầu, trước cả các import có thể print() - đảm bảo mọi dòng in
# tiếng Việt có dấu sau đó không làm sập chương trình vì lỗi encoding console
# (hay gặp nhất trên Windows 7 / cmd.exe dùng code page không phải UTF-8).
setup_console()

import executor
from executor import ACTIVE_REMINDERS, execute_command
from logging_setup import setup_logging
from nlu_advanced import NLU

logger = logging.getLogger(__name__)

BANNER = r"""
==============================================================
   TRỢ LÝ ẢO TIẾNG VIỆT - DEMO (11 Ý ĐỊNH + HIỂU Ý THÔNG MINH)
==============================================================
VÍ DỤ CÂU NÓI (gõ tay hoặc nói cũng được):
   Bật Google lên              mo chrome len       (không dấu vẫn hiểu)
   mở chorme ra                 (sai chính tả vẫn hiểu)
   mở chrome rồi phát nhạc trữ tình   (2 lệnh trong 1 câu)
   nhắc tôi họp lúc 3 giờ chiều
   thời tiết Đà Nẵng hôm nay thế nào
   15 cộng 27 bằng bao nhiêu
   mười lăm cộng hai mươi bảy bằng mấy   (số viết bằng chữ vẫn tính được)   [v6.2]
   mo chrome roi phat nhac              (không dấu vẫn tách 2 lệnh)        [v6.2]
   mấy giờ rồi

LỆNH ĐIỀU KHIỂN:
   mic          -> bật/tắt nghe qua micro (cần SpeechRecognition/PhoWhisper)
   voice        -> bật/tắt đọc phản hồi bằng giọng nói
   test         -> bật/tắt chế độ CHỈ PHÂN TÍCH (không thực thi) - nên bật
                   khi thử lệnh "tắt máy" để không bị shutdown thật
   nhac nho     -> xem danh sách nhắc nhở đang chờ
   huy nhac [từ khoá] -> huỷ nhắc nhở (bỏ trống = huỷ tất cả)      [MỚI v6]
   nap lai      -> nạp lại config.json, không cần khởi động lại   [MỚI v6]
   he thong     -> báo cáo khả năng của máy (hệ điều hành, công cụ) [v6.3]
   day <câu> = <intent>  -> dạy trợ lý hiểu đúng câu đó
   quen         -> xoá trí nhớ ngữ cảnh hội thoại
   help / giup  -> hiện lại hướng dẫn này
   thoat / exit -> thoát chương trình
==============================================================
"""

YES_WORDS = {"có", "co", "ừ", "u", "ủ", "đúng", "dung", "ok", "y", "yes", "vâng", "ừừ"}


def parse_args():
    parser = argparse.ArgumentParser(description="Trợ lý ảo tiếng Việt - demo hiểu ý + thực thi")
    parser.add_argument("--dry-run", action="store_true",
                         help="Chỉ phân tích câu nói, không thực thi lệnh (an toàn khi test)")
    parser.add_argument("--voice", action="store_true",
                         help="Nhận lệnh qua micro (cần: pip install SpeechRecognition pyaudio)")
    parser.add_argument("--speak", action="store_true",
                         help="Đọc phản hồi bằng giọng nói (cần: pip install pyttsx3)")
    # --- MỚI Ở v6: dùng trợ lý như một công cụ dòng lệnh, không chỉ là REPL ---
    parser.add_argument("--once", metavar="CÂU_LỆNH",
                         help='Chạy đúng MỘT câu lệnh rồi thoát (vd: --once "mở youtube")')
    parser.add_argument("--json", action="store_true",
                         help="In kết quả phân tích dạng JSON (dùng kèm --once)")
    parser.add_argument("--version", action="store_true",
                         help="In phiên bản + loại model đang dùng rồi thoát")
    # v6.3: báo cáo khả năng của máy - hệ điều hành, công cụ có sẵn, tính năng
    # nào sẽ chạy được. Hữu ích khi chẩn đoán "sao tính năng X không chạy".
    parser.add_argument("--sysinfo", action="store_true",
                         help="In báo cáo khả năng của máy rồi thoát")
    return parser.parse_args()


# ============================================================================
# LẤY ĐẦU VÀO (BÀN PHÍM HOẶC MIC)
# ============================================================================
def get_input(use_voice: bool) -> str:
    """Lấy câu nói kế tiếp: từ micro (nếu đang bật mic) hoặc từ bàn phím."""
    if use_voice:
        import stt
        if stt.is_available():
            text = stt.listen_once()
            if text:
                return text
            safe_print("(Không nhận diện được giọng nói, bạn có thể gõ tay bên dưới)")
        else:
            safe_print("[CẢNH BÁO] Chưa cài SpeechRecognition/pyaudio, chuyển sang gõ phím.")
    try:
        return input("\nBạn nói > ").strip()
    except (KeyboardInterrupt, EOFError):
        safe_print("\nTạm biệt!")
        sys.exit(0)


# ============================================================================
# XỬ LÝ + THỰC THI MỘT LỆNH ĐÃ ĐƯỢC NLU HIỂU
# ============================================================================
def handle_result(result: dict, nlu: NLU, dry_run: bool) -> None:
    """Xử lý một lệnh đã được tầng NLU hiểu (1 trong nhiều lệnh nếu câu có nhiều lệnh)."""
    status = result["status"]
    safe_print("Kết quả phân tích (JSON):")
    safe_print(json.dumps(
        {k: v for k, v in result.items() if k not in ("raw", "normalized")},
        ensure_ascii=False, indent=2,
    ))

    if status == "unknown":
        executor.respond("Xin lỗi, tôi chưa hiểu ý bạn")
        safe_print("   Mẹo: gõ  day <câu> = <intent>  để dạy tôi câu này.")
        return

    if status in ("low_confidence", "need_confirm"):
        question = nlu.confirm_message(result)
        executor.respond(question)
        safe_print(f"   [{result['confidence']:.0%} tự tin] ", end="")
        try:
            answer = input("").strip().lower()
        except (KeyboardInterrupt, EOFError):
            answer = ""
        if answer not in YES_WORDS:
            executor.respond("Đã huỷ lệnh")
            return
        nlu.teach(result["raw"], result["intent"])

    if dry_run:
        safe_print("   (Chế độ test: không thực thi)")
        return

    try:
        ok = execute_command(result)
    except Exception as e:
        # LƯỚI AN TOÀN QUAN TRỌNG: trước bản vá này, BẤT KỲ lỗi không lường
        # trước nào trong 1 handler (vd action_set_reminder nhận giờ ngoài
        # khoảng 0-23 từ 1 câu nói lạ, action_open_app gặp lỗi hệ thống hiếm
        # gặp...) sẽ làm SẬP TOÀN BỘ chương trình, mất hết ngữ cảnh hội thoại
        # + nhắc nhở đang chờ. Giờ chỉ báo lỗi + ghi log, phiên làm việc vẫn
        # tiếp tục bình thường.
        logger.exception("Lỗi không mong muốn khi thực thi lệnh (intent=%s)", result.get("intent"))
        safe_print(f"[LỖI] Có lỗi không mong muốn khi thực thi lệnh: {e}")
        safe_print("   (Đã ghi chi tiết vào logs/assistant.log - bạn thử lại hoặc nói câu khác nhé)")
        ok = False
    safe_print("=> " + ("Đã thực thi xong." if ok else "Không thực thi được."))


def print_sysinfo() -> None:
    """In báo cáo khả năng của máy (cờ --sysinfo / lệnh 'he thong') - v6.3."""
    from platform_utils import capability_report, format_capability_report
    safe_print(format_capability_report(capability_report()))


# ============================================================================
# MAIN LOOP
# ============================================================================
APP_VERSION = "6.4"


def run_once(text: str, nlu: NLU, dry_run: bool = False, as_json: bool = False) -> int:
    """Phân tích (và thực thi) đúng MỘT câu rồi thoát - mới ở v6.

    Dùng cho phím tắt, Task Scheduler, script shell hay kiểm thử tự động.
    Mã thoát: 0 = xong, 1 = có lệnh thất bại, 2 = không hiểu câu lệnh.
    """
    try:
        commands = nlu.understand(text)
    except Exception as e:
        logger.exception("Lỗi khi phân tích câu: %r", text)
        if as_json:
            print(json.dumps({"ok": False, "error": str(e), "raw": text}, ensure_ascii=False))
        else:
            safe_print(f"[LỖI] Không phân tích được: {e}")
        return 2

    if as_json:
        print(json.dumps(commands, ensure_ascii=False, indent=2, default=str))

    exit_code = 0
    for result in commands:
        if not as_json:
            safe_print("-> {0} | {1} | {2:.0%} | {3}".format(
                result["intent"], result["target"], result["confidence"], result["status"]))
        if dry_run:
            continue
        if result["status"] in ("ok", "low_confidence"):
            if not execute_command(result):
                exit_code = 1
        else:
            exit_code = 2
    return exit_code


def main():
    args = parse_args()

    # v6.3: xử lý sớm các cờ thông tin - không cần logging hay nạp model.
    if args.sysinfo:
        print_sysinfo()
        return 0

    setup_logging()

    if args.version:
        from intent_model import describe_engine
        safe_print(f"Trợ lý ảo tiếng Việt - phiên bản {APP_VERSION}")
        safe_print(f"Bộ hiểu ý: {describe_engine()}")
        return 0

    if not args.once:
        safe_print(BANNER)

    if args.voice:
        import stt
        if not stt.is_available():
            safe_print("[LƯU Ý] Bạn bật --voice nhưng chưa cài SpeechRecognition/pyaudio.\n"
                       "         Cài bằng:  pip install SpeechRecognition pyaudio\n"
                       "         Tạm thời chuyển sang chế độ gõ phím.\n")
    if args.speak:
        import tts
        if not tts.is_available():
            safe_print("[LƯU Ý] Bạn bật --speak nhưng chưa cài pyttsx3/gTTS.\n"
                       "         Cài bằng:  pip install pyttsx3\n"
                       "         Tạm thời chỉ in chữ, không đọc.\n")
        executor.set_speech_enabled(tts.is_available())

    if not args.once:
        safe_print("Đang nạp mô hình hiểu ý...")
    nlu = NLU()
    logger.info("Đã nạp model, bắt đầu phiên làm việc mới.")

    # v6: khôi phục các lời nhắc còn hạn từ lần chạy trước (trước đây thoát
    # chương trình là mất sạch nhắc nhở mà không hề báo gì).
    restored = executor.restore_reminders()
    if restored:
        safe_print(f"[NHẮC NHỞ] Đã khôi phục {restored} lời nhắc còn hạn từ lần chạy trước.")

    # v6: chế độ MỘT LỆNH -> làm xong thoát luôn, không vào vòng lặp hỏi đáp.
    if args.once:
        return run_once(args.once, nlu, dry_run=args.dry_run, as_json=args.json)

    safe_print("Sẵn sàng!\n")

    dry_run = args.dry_run
    mic_mode = args.voice

    while True:
        text = get_input(mic_mode)

        if not text:
            continue
        low = text.lower()

        # ---- Lệnh điều khiển chương trình ----
        if low in ("thoat", "thoát", "exit", "quit", "q"):
            safe_print("Tạm biệt!")
            logger.info("Kết thúc phiên làm việc.")
            break

        if low in ("help", "giup", "giúp", "?"):
            safe_print(BANNER)
            continue

        if low == "mic":
            mic_mode = not mic_mode
            if mic_mode:
                import stt
                if stt.is_available():
                    safe_print("[MIC] Bật chế độ nghe qua mic.")
                else:
                    safe_print("[MIC] Chưa cài SpeechRecognition/pyaudio, không bật được.")
                    mic_mode = False
            else:
                safe_print("[MIC] Tắt chế độ mic, quay về gõ tay.")
            continue

        if low == "voice":
            import tts
            executor.set_speech_enabled(not executor.SPEAK_ENABLED)
            if executor.SPEAK_ENABLED and not tts.is_available():
                safe_print("[VOICE] Chưa cài engine giọng nói nào (pyttsx3/gTTS) - sẽ chỉ in chữ.")
            safe_print(f"[VOICE] Đọc phản hồi bằng giọng nói = {executor.SPEAK_ENABLED}")
            continue

        if low == "test":
            dry_run = not dry_run
            safe_print(f"[TEST] Chỉ phân tích = {dry_run}")
            continue

        if low in ("nhac nho", "nhắc nhở"):
            if not ACTIVE_REMINDERS:
                safe_print("(Chưa có nhắc nhở nào đang chờ)")
            else:
                for i, r in enumerate(ACTIVE_REMINDERS, 1):
                    safe_print(f"  {i}. {r['task']} - {r['at']:%H:%M %d/%m}")
                safe_print("   (Gõ 'huy nhac <từ khoá>' để huỷ, hoặc 'huy nhac' để huỷ tất cả)")
            continue

        # v6: HUỶ nhắc nhở - trước đây lỡ đặt nhầm giờ thì không có cách nào gỡ,
        # ngoài việc thoát hẳn chương trình.
        if low.startswith(("huy nhac", "huỷ nhắc", "hủy nhắc")):
            parts = text.split(None, 2)
            removed = executor.cancel_reminder(parts[2] if len(parts) > 2 else None)
            if removed:
                for r in removed:
                    safe_print(f"[ĐÃ HUỶ] {r['task']} - {r['at']:%H:%M %d/%m}")
            else:
                safe_print("(Không tìm thấy nhắc nhở nào khớp để huỷ)")
            continue

        # v6: nạp lại config.json mà không phải khởi động lại trợ lý.
        if low in ("nap lai", "nạp lại", "reload"):
            cfg = executor.reload_config()
            safe_print(f"[CẤU HÌNH] Đã nạp lại config.json "
                       f"({len(cfg['website_map'])} web, {len(cfg['file_map'])} file).")
            continue

        # v6.3: xem báo cáo khả năng của máy ngay trong phiên.
        if low in ("he thong", "hệ thống", "sysinfo"):
            print_sysinfo()
            continue

        if low in ("quen", "quên", "reset"):
            if nlu.context:
                nlu.context.clear()
            safe_print("[NGỮ CẢNH] Đã xoá trí nhớ hội thoại.")
            continue

        if low.startswith(("day ", "dạy ")):
            body = text[4:]
            if "=" not in body:
                safe_print("Cú pháp:  day <câu nói> = <tên intent>")
            else:
                sentence, intent = (p.strip() for p in body.split("=", 1))
                safe_print(nlu.teach(sentence, intent))
            continue

        # ---- Hiểu ý + thực thi ----
        if mic_mode:
            safe_print(f"[MIC] Bạn nói: {text}")

        try:
            commands = nlu.understand(text)
        except Exception as e:
            logger.exception("Lỗi không mong muốn khi phân tích câu nói: %r", text)
            safe_print(f"[LỖI] Không phân tích được câu vừa rồi: {e}")
            safe_print("   (Đã ghi log - bạn thử nói lại câu khác nhé)")
            continue

        if len(commands) > 1:
            safe_print(f"(Phát hiện {len(commands)} lệnh trong câu)")

        for i, result in enumerate(commands, 1):
            if len(commands) > 1:
                safe_print(f"\n--- LỆNH {i}: {result['raw']} ---")
            try:
                handle_result(result, nlu, dry_run)
            except Exception as e:
                # Lớp bọc THỨ HAI (phòng hờ) - execute_command() bên trong
                # handle_result() đã có lớp bọc riêng, đây là lưới an toàn
                # cuối cùng cho lỗi phát sinh ở NHỮNG chỗ khác trong
                # handle_result() (vd bước xác nhận, in JSON kết quả...).
                logger.exception("Lỗi không mong muốn khi xử lý lệnh")
                safe_print(f"[LỖI] Có lỗi không mong muốn: {e}")
                safe_print("   Phiên làm việc vẫn tiếp tục bình thường.")


if __name__ == "__main__":
    # v6: trả mã thoát cho shell (0 = OK) để dùng được trong script/CI.
    sys.exit(main() or 0)
