# -*- coding: utf-8 -*-
"""
executor.py
-----------
MÔ-ĐUN THỰC THI LỆNH TRÊN MÁY TÍNH - hỗ trợ Windows / macOS / Linux.

BẢN KẾT HỢP (v5): 11 intent, chia làm 2 nhóm phong cách phản hồi:

  * NHÓM "HÀNH ĐỘNG HỆ THỐNG" (open_website, open_app, open_file,
    system_control): giữ NGUYÊN toàn bộ nền tảng bảo mật/đa nền tảng từ bản
    trước - đây là phần dễ gây hại nhất nếu làm sai:
      - Mở app CHỈ được phép với ứng dụng có trong whitelist (config.json),
        không còn chạy thẳng văn bản người dùng nói qua shell=True (vá lỗi
        command injection).
      - Toàn bộ subprocess dùng list-args, không shell=True.
      - action_open_app() / action_system_control() tự chọn đúng bảng ánh xạ
        / lệnh hệ thống theo platform.system() (Windows/macOS/Linux) thay vì
        chỉ hoạt động thật trên Windows.
      - action_open_website() không còn "sửa nhầm" 1 URL tường minh (kèm
        đường dẫn) thành 1 site gần giống trong config; dùng quote_plus để
        mã hoá query đúng chuẩn.
      - execute_command() không hạ chữ thường toàn bộ target (tránh phá vỡ
        ID video YouTube, đường dẫn file phân biệt hoa/thường).
      - Log qua module `logging` (file logs/assistant.log), in ra màn hình
        theo phong cách "nhật ký hệ thống": [THỰC THI] / [TỪ CHỐI] / [LỖI].

  * NHÓM "PHẢN HỒI HỘI THOẠI" (search_web, play_media, set_reminder,
    get_weather, get_datetime, calculate, chitchat): không đụng tới tài
    nguyên nhạy cảm của máy (chỉ mở trình duyệt tìm kiếm, hẹn giờ nội bộ,
    hoặc trả lời bằng giọng nói), nên giữ phong cách hội thoại của bản
    "nhiều tính năng": in + có thể ĐỌC phản hồi bằng giọng nói (tts.py) qua
    hàm respond(). Xem SPEAK_ENABLED bên dưới.

Hàm chính: execute_command(intent_json)
    Đầu vào: dict hoặc chuỗi JSON dạng
        {"intent": "open_website", "target": "google", "confidence": 0.93}
"""

import datetime
import difflib
import json
import logging
import os
import platform
import random
import re
import subprocess
import threading
import urllib.parse
import uuid
import webbrowser

from config import load_config
from text_utils import strip_diacritics
from platform_utils import (is_windows7_or_older, windows_version_label,
                            setup_console, safe_print, is_wsl)

logger = logging.getLogger(__name__)

# rapidfuzz là extension biên dịch sẵn (C++) - trên một số máy Windows cũ
# (đặc biệt Windows 7 chưa cài Visual C++ Redistributable 2015-2022) việc
# import có thể lỗi (thiếu file .dll) dù đã `pip install` thành công. Thay vì
# làm sập toàn bộ chương trình, chuyển sang so khớp bằng difflib (có sẵn
# trong Python, không cần cài thêm) - kém chính xác hơn một chút với lỗi
# chính tả nặng nhưng vẫn hoạt động được.
try:
    from rapidfuzz import fuzz, process
    _RAPIDFUZZ_AVAILABLE = True
except ImportError:
    _RAPIDFUZZ_AVAILABLE = False
    logger.warning(
        "Không nạp được rapidfuzz (có thể do thiếu Visual C++ Redistributable "
        "trên Windows) - chuyển sang so khớp dự phòng bằng difflib."
    )

SYSTEM = platform.system()  # "Windows" | "Darwin" (macOS) | "Linux"
CONFIG = load_config()

CONFIDENCE_THRESHOLD = CONFIG["confidence_threshold"]
DANGEROUS_ACTIONS = set(CONFIG["dangerous_actions"])


def reload_config(path: str = None) -> dict:
    """Nạp lại config.json NGAY KHI ĐANG CHẠY (bản v6).

    Trước đây cấu hình chỉ được đọc đúng 1 lần lúc import module, nên thêm
    1 trang web / 1 ứng dụng vào config.json bắt buộc phải thoát và mở lại
    trợ lý. Cập nhật TẠI CHỖ dict CONFIG để mọi tham chiếu cũ vẫn trỏ đúng
    đối tượng.
    """
    global CONFIDENCE_THRESHOLD, DANGEROUS_ACTIONS
    fresh = load_config(path) if path else load_config()
    CONFIG.clear()
    CONFIG.update(fresh)
    CONFIDENCE_THRESHOLD = CONFIG["confidence_threshold"]
    DANGEROUS_ACTIONS = set(CONFIG["dangerous_actions"])
    logger.info("Đã nạp lại cấu hình: %d trang web, %d file",
                len(CONFIG.get("website_map", {})), len(CONFIG.get("file_map", {})))
    return CONFIG


def set_speech_enabled(enabled: bool) -> bool:
    """Bật/tắt đọc phản hồi bằng giọng nói.

    Dùng hàm này thay cho việc gán thẳng `executor.SPEAK_ENABLED = True` từ
    module khác (cách cũ dễ gây sai sót và khó lần theo khi có lỗi).
    """
    global SPEAK_ENABLED
    SPEAK_ENABLED = bool(enabled)
    return SPEAK_ENABLED

# Bật/tắt việc ĐỌC phản hồi bằng giọng nói cho nhóm "phản hồi hội thoại"
# (xem respond() bên dưới). main.py bật cờ này khi người dùng dùng --speak
# hoặc gõ lệnh "voice" trong demo. Mặc định TẮT để không phát âm thanh ngoài
# ý muốn khi chạy trong script/test tự động.
SPEAK_ENABLED = False

# Chỉ cho phép ký tự an toàn khi mở app không nằm trong whitelist nhưng có vẻ
# là 1 tên file .exe hợp lệ do người dùng gõ trực tiếp đường dẫn tuyệt đối có
# sẵn trên máy (không phải suy đoán tự do từ câu nói)
_SAFE_PATH_RE = re.compile(r"^[\w\s:\\/.\-()%]+$", re.UNICODE)

# Dùng để nhận diện URL/tên miền hợp lệ trong action_open_website (thay cho
# kiểm tra lỏng lẻo `target.startswith("http")` - chuỗi như "httpxyz..."
# KHÔNG có scheme thật cũng đi qua được kiểm tra lỏng lẻo đó).
_URL_SCHEME_RE = re.compile(r"^https?://", re.IGNORECASE)
# Tên miền trần, có thể kèm đường dẫn phía sau (vd "github.com/abc/xyz").
_BARE_DOMAIN_RE = re.compile(r"^[\w.\-]+\.[a-z]{2,}(?:/\S*)?$", re.IGNORECASE)

HOME = os.path.expanduser("~")

# Danh sách nhắc nhở đang chờ (để tra cứu / hiển thị trong demo)
ACTIVE_REMINDERS = []

# v6: nơi lưu nhắc nhở ra đĩa để KHÔNG mất khi thoát / khởi động lại.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
REMINDERS_PATH = os.path.join(BASE_DIR, "reminders.json")

# Phần mở rộng CHẠY ĐƯỢC: "mở file" bằng giọng nói không bao giờ nên khởi
# chạy mã thực thi (xem action_open_file bên dưới).
EXECUTABLE_EXTENSIONS = {
    ".exe", ".bat", ".cmd", ".com", ".scr", ".pif", ".msi", ".msp", ".ps1",
    ".psm1", ".vbs", ".vbe", ".js", ".jse", ".jar", ".wsf", ".wsh", ".hta",
    ".cpl", ".reg", ".sh", ".bash", ".zsh", ".py", ".pyw", ".app",
}

# --- Câu trả lời cho trò chuyện vặt (chitchat) ---
CHITCHAT_REPLIES = [
    (r"xin chào|chào bạn|hello|hi bạn|chào trợ lý|alô",
     ["Xin chào! Tôi có thể giúp gì cho bạn?", "Chào bạn, tôi đang nghe đây."]),
    (r"chào buổi sáng", ["Chào buổi sáng! Chúc bạn một ngày hiệu quả."]),
    (r"chào buổi tối|ngủ ngon", ["Chúc bạn buổi tối vui vẻ và ngủ ngon nhé."]),
    (r"tên gì|là ai|ai tạo ra bạn",
     ["Tôi là trợ lý ảo tiếng Việt, giúp bạn điều khiển máy tính bằng giọng nói."]),
    (r"làm được|giúp được|làm những gì",
     ["Tôi có thể mở trang web, mở phần mềm, mở file, tìm kiếm, phát nhạc, "
      "đặt nhắc nhở, xem thời tiết, tính toán và điều khiển hệ thống."]),
    (r"khoẻ không|thế nào|đang làm gì",
     ["Tôi vẫn chạy tốt và sẵn sàng nhận lệnh của bạn."]),
    (r"cảm ơn|cám ơn|giỏi|tốt lắm|okie",
     ["Không có gì, rất vui được giúp bạn.", "Dạ vâng, có gì bạn cứ gọi tôi."]),
    (r"tạm biệt|bái bai|hẹn gặp lại",
     ["Tạm biệt bạn, hẹn gặp lại!"]),
    (r"buồn|mệt|tâm sự",
     ["Bạn nghỉ ngơi một chút nhé. Tôi có thể mở một bản nhạc nhẹ cho bạn."]),
    (r"chuyện cười|nói đùa|hát",
     ["Lập trình viên sợ nhất điều gì? Là code chạy được mà không biết tại sao!"]),
    (r"bao nhiêu tuổi", ["Tôi vừa được bạn tạo ra thôi, còn rất trẻ!"]),
]


# ============================================================================
# 1. HÀM HỖ TRỢ SO KHỚP (khoan dung dấu + lỗi chính tả nhẹ, dùng rapidfuzz)
# ============================================================================
def _best_match(target: str, mapping: dict, score_cutoff: int = 78, fuzzy: bool = True):
    """
    Tìm khoá khớp tốt nhất trong mapping.

    Thứ tự ưu tiên:
      1. Khớp tuyệt đối (có dấu).
      2. Khớp tuyệt đối sau khi bỏ dấu.
      3. Fuzzy matching (rapidfuzz, hoặc difflib nếu rapidfuzz không cài
         được) để chịu được lỗi chính tả nhẹ, chỉ chấp nhận nếu điểm khớp
         >= score_cutoff (mặc định 78/100).

    fuzzy=False: chỉ thử bước 1-2 (khớp tuyệt đối), bỏ qua fuzzy matching -
        dùng khi caller cần phân biệt rạch ròi "có khớp đúng 1 mục đã cấu
        hình sẵn hay không" trước khi tự quyết định cách xử lý khác (vd
        action_open_website() cần biết chắc target KHÔNG khớp đúng mục nào
        trước khi coi nó là 1 URL/tên miền tường minh - xem ghi chú ở đó).
    """
    if not target:
        return None, None
    target = target.strip().lower()

    if target in mapping:
        return mapping[target], target

    no_dia = strip_diacritics(target)
    for key, value in mapping.items():
        if strip_diacritics(key) == no_dia:
            return value, key

    if not fuzzy:
        return None, None

    if _RAPIDFUZZ_AVAILABLE:
        match = process.extractOne(
            target, mapping.keys(), scorer=fuzz.WRatio, score_cutoff=score_cutoff
        )
        if match:
            matched_key = match[0]
            return mapping[matched_key], matched_key
        return None, None

    # --- Dự phòng khi rapidfuzz không khả dụng: difflib (thư viện chuẩn) ---
    close = difflib.get_close_matches(
        target, mapping.keys(), n=1, cutoff=score_cutoff / 100
    )
    if close:
        matched_key = close[0]
        return mapping[matched_key], matched_key

    return None, None


def _confirm(prompt: str) -> bool:
    """Hỏi xác nhận (y/n) trước khi thực hiện hành động nhạy cảm.

    Mặc định trả về False (KHÔNG xác nhận - an toàn hơn) nếu không lấy được
    input() (vd EOFError khi stdin không tương tác được, hoặc người dùng
    nhấn Ctrl+C) - tránh để 1 lệnh NGUY HIỂM (tắt máy, khởi động lại...) làm
    sập chương trình ngay tại bước hỏi xác nhận, hoặc tệ hơn là lỡ thực thi
    mà không có xác nhận thật.
    """
    try:
        answer = input(f"[XÁC NHẬN] {prompt} (y/n): ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        safe_print("\n[HUỶ] Không lấy được xác nhận từ bàn phím - huỷ lệnh để an toàn.")
        return False
    return answer == "y"


def respond(text: str) -> None:
    """
    In phản hồi ra màn hình theo phong cách hội thoại (dùng bởi nhóm intent
    "phản hồi hội thoại": search_web, play_media, set_reminder, get_weather,
    get_datetime, calculate, chitchat). Nếu SPEAK_ENABLED = True, cũng ĐỌC
    to bằng giọng nói (tts.py) - import trễ (bên trong hàm) để executor.py
    vẫn dùng được, kể cả khi chưa cài pyttsx3/gTTS hoặc đang chạy trong môi
    trường test không có thiết bị âm thanh.
    """
    safe_print(f"[TRỢ LÝ] {text}")
    if SPEAK_ENABLED:
        try:
            import tts
            tts.speak(text, show=False)
        except Exception as e:
            logger.warning("Không đọc được phản hồi bằng giọng nói: %s", e)


def _open_url(url: str) -> bool:
    """Mở URL bằng trình duyệt mặc định. Trả về True/False tuỳ có mở được không.

    v6.3: có đường riêng cho WSL - webbrowser.open() trên WSL thường âm thầm
    không mở gì (không có trình duyệt Linux trong PATH), nên chuyển sang gọi
    trình duyệt của Windows host qua wslview / explorer.exe.
    """
    if SYSTEM == "Linux" and is_wsl():
        if _run_first_available([["wslview", url], ["explorer.exe", url]]):
            return True
        logger.warning("WSL: không tìm thấy wslview/explorer.exe để mở URL %s", url)
        return False
    try:
        return bool(webbrowser.open(url))
    except Exception as e:
        logger.warning("webbrowser.open(%r) lỗi: %s", url, e)
        return False


def _open_path(path: str) -> bool:
    """Mở 1 file / thư mục bằng ứng dụng mặc định của hệ điều hành."""
    path = os.path.expandvars(os.path.expanduser(path))
    if not os.path.exists(path):
        safe_print(f"[LỖI] Không tìm thấy đường dẫn: {path}")
        logger.warning("Không tìm thấy đường dẫn: %s", path)
        return False
    try:
        if SYSTEM == "Windows":
            os.startfile(path)  # chỉ có trên Windows
        elif SYSTEM == "Darwin":
            subprocess.Popen(["open", path])
        elif is_wsl():
            # v6.3: trên WSL, xdg-open thường không mở được gì - dùng trình
            # mở của Windows host (wslview tự dịch đường dẫn Linux -> Windows).
            if not _run_first_available([["wslview", path]]):
                safe_print("[LỖI] Trên WSL cần cài wslu (wslview) để mở file/thư mục: "
                           "sudo apt install wslu")
                return False
        else:
            subprocess.Popen(["xdg-open", path])
        return True
    except Exception as e:
        safe_print(f"[LỖI] Không mở được {path}: {e}")
        logger.error("Không mở được %s: %s", path, e)
        return False


def _volume_via_pycaw(target: str):
    """
    Điều khiển âm lượng CHÍNH XÁC qua Windows Core Audio API (thư viện pycaw).
    Trả về True/False nếu xử lý được bằng pycaw, hoặc None nếu pycaw chưa cài
    (chương trình sẽ tự động dùng lại cách cũ - gửi phím ảo qua PowerShell).
    """
    try:
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
    except ImportError:
        return None

    try:
        speakers = AudioUtilities.GetSpeakers()
        interface = speakers.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        volume = interface.QueryInterface(IAudioEndpointVolume)

        if target == "mute":
            volume.SetMute(1, None)
        elif target == "unmute":
            volume.SetMute(0, None)
        elif target == "volume_up":
            level = min(1.0, volume.GetMasterVolumeLevelScalar() + 0.1)
            volume.SetMasterVolumeLevelScalar(level, None)
        elif target == "volume_down":
            level = max(0.0, volume.GetMasterVolumeLevelScalar() - 0.1)
            volume.SetMasterVolumeLevelScalar(level, None)
        else:
            return None
        return True
    except Exception as e:
        logger.warning("pycaw lỗi khi điều chỉnh âm lượng '%s': %s", target, e)
        return None


def _app_map_for_platform() -> dict:
    """Trả về mapping tên-app -> lệnh/đường-dẫn PHÙ HỢP với hệ điều hành đang chạy."""
    if SYSTEM == "Darwin":
        return CONFIG.get("app_map_macos", {})
    if SYSTEM == "Windows":
        return CONFIG.get("app_map_windows", {})
    return CONFIG.get("app_map_linux", {})


# ============================================================================
# 2A. HÀNH ĐỘNG "HỆ THỐNG" (whitelist, đa nền tảng, không shell=True)
# ============================================================================
def action_open_website(target: str) -> bool:
    """Mở trang web tương ứng bằng trình duyệt mặc định.

    THỨ TỰ ƯU TIÊN:
      1. Khớp TUYỆT ĐỐI với 1 mục đã cấu hình trong website_map (vd "google").
      2. Target đã là URL/tên miền tường minh (có scheme http(s):// hoặc dạng
         "abc.com" / "abc.com/duong/dan") -> dùng NGUYÊN VĂN, không "sửa" lại.
      3. Chỉ khi KHÔNG rơi vào 2 trường hợp trên mới cho phép fuzzy match
         (khoan dung lỗi chính tả) với website_map.
      4. Không khớp gì cả -> tìm trên Google (mã hoá đúng chuẩn bằng quote_plus).
    """
    url, matched_key = _best_match(target, CONFIG["website_map"], fuzzy=False)

    if url is None:
        if _URL_SCHEME_RE.match(target):
            url = target
        elif _BARE_DOMAIN_RE.match(target):
            url = "https://" + target
        else:
            url, matched_key = _best_match(target, CONFIG["website_map"])
            if url is None:
                url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(target)

    safe_print(f"[THỰC THI] Mở trình duyệt: {url}")
    logger.info("Mở website: target=%r matched=%r url=%s", target, matched_key, url)
    _open_url(url)
    return True


def action_open_app(target: str) -> bool:
    """
    Mở ứng dụng trên máy.

    Vì lý do bảo mật, CHỈ mở được ứng dụng có trong whitelist (app_map_windows
    / app_map_macos / app_map_linux tuỳ hệ điều hành đang chạy, trong
    config.json). Nếu người dùng nói tên ứng dụng chưa có trong danh sách,
    chương trình sẽ từ chối và gợi ý cách thêm vào config.
    """
    config_key = {"Windows": "app_map_windows", "Darwin": "app_map_macos"}.get(SYSTEM, "app_map_linux")
    exe, matched_key = _best_match(target, _app_map_for_platform())

    if exe is not None and SYSTEM == "Windows" and re.match(r"^[\w.]+:$", exe) and is_windows7_or_older():
        safe_print(
            f"[TỪ CHỐI] '{matched_key}' là ứng dụng kiểu Store App (UWP), "
            f"chỉ chạy được từ Windows 8 trở lên - máy bạn đang chạy "
            f"{windows_version_label()}. Hãy đổi mục \"{matched_key}\" trong "
            f"config.json sang đường dẫn .exe của app tương đương (nếu có)."
        )
        logger.warning("Từ chối mở app UWP '%s' trên %s", matched_key, windows_version_label())
        return False

    if exe is None:
        safe_print(
            f"[TỪ CHỐI] Chưa biết ứng dụng '{target}'. "
            f"Hãy thêm vào mục \"{config_key}\" trong config.json, ví dụ:\n"
            f'  "{target}": "duong_dan_toi_file.exe"'
        )
        logger.warning("Từ chối mở app không có trong whitelist (%s): %r", config_key, target)
        return False

    exe = os.path.expandvars(exe)
    safe_print(f"[THỰC THI] Mở ứng dụng: {exe} (khớp với '{matched_key}')")
    logger.info("Mở app: target=%r matched=%r exe=%s", target, matched_key, exe)
    try:
        if SYSTEM == "Windows":
            subprocess.Popen(["cmd", "/c", "start", "", exe])
        elif SYSTEM == "Darwin":
            subprocess.Popen(["open", "-a", exe])
        else:
            import shlex
            subprocess.Popen(shlex.split(exe))
        return True
    except FileNotFoundError:
        safe_print(
            f"[LỖI] Không tìm thấy lệnh '{exe}' trên máy. Ứng dụng có thể "
            f"chưa được cài đặt, hoặc tên lệnh không khớp với máy bạn - hãy "
            f"sửa mục \"{matched_key}\" trong \"{config_key}\" (config.json)."
        )
        logger.error("Không tìm thấy lệnh '%s' (target=%r)", exe, target)
        return False
    except Exception as e:
        safe_print(f"[LỖI] Không mở được ứng dụng '{exe}': {e}")
        logger.error("Không mở được ứng dụng '%s': %s", exe, e)
        return False


def _run_first_available(candidates) -> bool:
    """Thử lần lượt từng lệnh trong `candidates` cho đến khi có 1 lệnh khởi chạy được."""
    for cmd in candidates:
        try:
            subprocess.Popen(cmd)
            logger.info("Lệnh hệ thống chạy thành công: %s", cmd)
            return True
        except FileNotFoundError:
            continue
    return False


def _is_executable_path(path: str) -> bool:
    """File này có phải loại CHẠY ĐƯỢC (chương trình/script) hay không?"""
    cleaned = (path or "").strip().rstrip("\"'")
    return os.path.splitext(cleaned)[1].lower() in EXECUTABLE_EXTENSIONS


def action_open_file(target: str) -> bool:
    """Mở file / thư mục theo tên gợi nhớ hoặc đường dẫn trực tiếp."""
    path, matched_key = _best_match(target, CONFIG["file_map"])
    if path is None:
        if target and _SAFE_PATH_RE.match(target) and ".." not in target:
            path = target
        else:
            safe_print(f"[TỪ CHỐI] Không nhận diện được file/thư mục '{target}'. "
                  f"Hãy thêm vào mục \"file_map\" trong config.json.")
            logger.warning("Từ chối mở file không xác định: %r", target)
            return False
    # LỚP BẢO VỆ MỚI (v6): không bao giờ tự động mở file thực thi. Trước đây
    # một câu vô hại như "mở file setup.exe trong thư mục tải xuống" sẽ CHẠY
    # luôn chương trình đó (os.startfile tương đương nháy đúp chuột) - biến
    # lệnh "mở file" thành lệnh chạy mã tuỳ ý, lỗ hổng lớn nhất còn lại của bản v5.
    if _is_executable_path(path):
        safe_print(f"[TỪ CHỐI] '{path}' là file CÓ THỂ CHẠY ĐƯỢC (chương trình/script). "
                   f"Vì an toàn, tôi không tự mở loại file này.")
        logger.warning("Từ chối mở file thực thi: %s", path)
        return False

    safe_print(f"[THỰC THI] Mở file: {path}")
    logger.info("Mở file: target=%r matched=%r path=%s", target, matched_key, path)
    return _open_path(path)


def _system_control_wsl(target: str) -> bool:
    """Thực thi lệnh hệ thống trên Windows HOST khi đang chạy trong WSL (v6.3).

    WSL không có systemctl/pactl/màn hình thật, nhưng gọi được phần thực thi
    của Windows qua interop (shutdown.exe, rundll32.exe, powershell.exe).
    """
    commands = {
        "shutdown": ["shutdown.exe", "/s", "/t", "5"],
        "restart": ["shutdown.exe", "/r", "/t", "5"],
        "logout": ["shutdown.exe", "/l"],
        "lock": ["rundll32.exe", "user32.dll,LockWorkStation"],
        "sleep": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
    }
    if target in commands:
        try:
            subprocess.Popen(commands[target])
            safe_print(f"[THỰC THI] Lệnh hệ thống (WSL -> Windows host): {target}")
            logger.info("Lệnh hệ thống qua Windows host (WSL): %s", target)
            return True
        except FileNotFoundError:
            safe_print("[LỖI] Không gọi được lệnh Windows từ WSL (interop đang tắt? "
                       "kiểm tra /etc/wsl.conf).")
            logger.error("WSL interop không khả dụng cho lệnh: %s", target)
            return False

    if target in ("mute", "unmute", "volume_up", "volume_down"):
        key = {"mute": 173, "unmute": 173, "volume_down": 174, "volume_up": 175}[target]
        repeat = 5 if target in ("volume_up", "volume_down") else 1
        ps = ("$w = New-Object -ComObject WScript.Shell; "
              f"1..{repeat} | ForEach-Object {{ $w.SendKeys([char]{key}) }}")
        try:
            subprocess.Popen(["powershell.exe", "-NoProfile", "-Command", ps])
            safe_print(f"[THỰC THI] Điều chỉnh âm thanh (WSL -> Windows host): {target}")
            return True
        except FileNotFoundError:
            safe_print("[LỖI] Không gọi được powershell.exe từ WSL.")
            return False

    if target == "screenshot":
        # Chụp màn hình của Windows host, lưu vào Pictures của Windows.
        ps = ("Add-Type -AssemblyName System.Windows.Forms,System.Drawing; "
              "$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; "
              "$bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height; "
              "$g = [System.Drawing.Graphics]::FromImage($bmp); "
              "$g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size); "
              "$dir = [Environment]::GetFolderPath('MyPictures'); "
              "$path = Join-Path $dir ('screenshot_{0:yyyyMMdd_HHmmss}.png' -f (Get-Date)); "
              "$bmp.Save($path); Write-Output $path")
        try:
            out = subprocess.run(["powershell.exe", "-NoProfile", "-Command", ps],
                                 check=True, capture_output=True, text=True)
            safe_print(f"[THỰC THI] Đã chụp màn hình (Windows host): {out.stdout.strip()}")
            return True
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            safe_print(f"[LỖI] Không chụp được màn hình qua Windows host: {e}")
            return False

    safe_print(f"[BỎ QUA] WSL chưa hỗ trợ lệnh '{target}'.")
    return False


def action_system_control(target: str) -> bool:
    """Thực hiện lệnh hệ thống: tắt máy, restart, khoá máy, âm lượng, chụp màn hình..."""
    if target in DANGEROUS_ACTIONS:
        if not _confirm(f"Bạn chắc chắn muốn '{target}'?"):
            safe_print("Đã huỷ lệnh.")
            logger.info("Người dùng huỷ lệnh nguy hiểm: %s", target)
            return False

    # ---------------- WINDOWS ----------------
    commands_windows = {
        "shutdown": ["shutdown", "/s", "/t", "5"],
        "restart": ["shutdown", "/r", "/t", "5"],
        "logout": ["shutdown", "/l"],
        "lock": ["rundll32.exe", "user32.dll,LockWorkStation"],
        "sleep": ["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"],
    }
    volume_keys = {"mute": 173, "unmute": 173, "volume_down": 174, "volume_up": 175}

    # ---------------- macOS ----------------
    commands_macos = {
        "shutdown": ["osascript", "-e", 'tell app "System Events" to shut down'],
        "restart": ["osascript", "-e", 'tell app "System Events" to restart'],
        "logout": ["osascript", "-e", 'tell app "System Events" to log out'],
        "lock": ["osascript", "-e",
                 'tell application "System Events" to keystroke "q" using {control down, command down}'],
        "sleep": ["pmset", "sleepnow"],
    }
    volume_macos = {
        "mute": ["osascript", "-e", "set volume output muted true"],
        "unmute": ["osascript", "-e", "set volume output muted false"],
        "volume_up": ["osascript", "-e",
                      "set volume output volume ((output volume of (get volume settings)) + 10)"],
        "volume_down": ["osascript", "-e",
                        "set volume output volume ((output volume of (get volume settings)) - 10)"],
    }

    # ---------------- Linux ----------------
    commands_linux = {
        "shutdown": [["systemctl", "poweroff"], ["shutdown", "-h", "now"]],
        "restart": [["systemctl", "reboot"], ["shutdown", "-r", "now"]],
        "logout": [["loginctl", "terminate-user", os.environ.get("USER", "")],
                   ["gnome-session-quit", "--logout", "--no-prompt"]],
        # v6.3: thêm qdbus cho KDE Plasma (trước đây lock trên KDE thất bại
        # nếu máy không có xdg-screensaver/gnome-screensaver).
        "lock": [["loginctl", "lock-session"], ["xdg-screensaver", "lock"],
                 ["gnome-screensaver-command", "-l"],
                 ["qdbus", "org.freedesktop.ScreenSaver", "/ScreenSaver", "Lock"],
                 ["dm-tool", "lock"]],
        "sleep": [["systemctl", "suspend"]],
    }
    volume_linux = {
        # v6.3: thử wpctl (PipeWire - chuẩn trên distro mới) TRƯỚC pactl/amixer.
        "mute": [["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "1"],
                 ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1"],
                 ["amixer", "set", "Master", "mute"]],
        "unmute": [["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "0"],
                   ["pactl", "set-sink-mute", "@DEFAULT_SINK@", "0"],
                   ["amixer", "set", "Master", "unmute"]],
        "volume_up": [["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "10%+"],
                      ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "+10%"],
                      ["amixer", "set", "Master", "10%+"]],
        "volume_down": [["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "10%-"],
                        ["pactl", "set-sink-volume", "@DEFAULT_SINK@", "-10%"],
                        ["amixer", "set", "Master", "10%-"]],
    }

    try:
        if SYSTEM == "Windows":
            if target in commands_windows:
                safe_print(f"[THỰC THI] {' '.join(commands_windows[target])}")
                logger.info("Lệnh hệ thống (Windows): %s", target)
                subprocess.Popen(commands_windows[target])
                return True

            if target in volume_keys:
                if _volume_via_pycaw(target):
                    safe_print(f"[THỰC THI] Điều chỉnh âm thanh (pycaw, chính xác): {target}")
                    logger.info("Điều chỉnh âm thanh qua pycaw: %s", target)
                    return True

                key = volume_keys[target]
                repeat = 5 if target in ("volume_up", "volume_down") else 1
                ps = (
                    "$w = New-Object -ComObject WScript.Shell; "
                    f"1..{repeat} | ForEach-Object {{ $w.SendKeys([char]{key}) }}"
                )
                subprocess.Popen(["powershell", "-NoProfile", "-Command", ps])
                safe_print(f"[THỰC THI] Điều chỉnh âm thanh (phím ảo): {target}")
                if target == "unmute":
                    safe_print("[LƯU Ý] Cài thêm `pip install pycaw comtypes` để 'unmute' "
                          "chính xác tuyệt đối thay vì chỉ bật/tắt luân phiên.")
                logger.info("Điều chỉnh âm thanh qua phím ảo: %s", target)
                return True

            if target == "screenshot":
                pictures_dir = os.path.join(HOME, "Pictures")
                os.makedirs(pictures_dir, exist_ok=True)
                path = os.path.join(pictures_dir,
                                    f"screenshot_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
                ps = ("Add-Type -AssemblyName System.Windows.Forms,System.Drawing; "
                      "$b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; "
                      "$bmp = New-Object System.Drawing.Bitmap $b.Width, $b.Height; "
                      "$g = [System.Drawing.Graphics]::FromImage($bmp); "
                      "$g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size); "
                      f"$bmp.Save('{path}')")
                subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True)
                safe_print(f"[THỰC THI] Đã chụp màn hình: {path}")
                logger.info("Đã chụp màn hình: %s", path)
                return True

        elif SYSTEM == "Darwin":
            if target in commands_macos:
                safe_print(f"[THỰC THI] Lệnh hệ thống (macOS): {target}")
                logger.info("Lệnh hệ thống (macOS): %s", target)
                subprocess.Popen(commands_macos[target])
                return True

            if target in volume_macos:
                safe_print(f"[THỰC THI] Điều chỉnh âm thanh (macOS): {target}")
                logger.info("Điều chỉnh âm thanh (macOS): %s", target)
                subprocess.Popen(volume_macos[target])
                return True

            if target == "screenshot":
                pictures_dir = os.path.join(HOME, "Pictures")
                os.makedirs(pictures_dir, exist_ok=True)
                path = os.path.join(pictures_dir,
                                    f"screenshot_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
                subprocess.Popen(["screencapture", path])
                safe_print(f"[THỰC THI] Đã chụp màn hình: {path}")
                return True

        else:  # Linux (và các hệ Unix tương tự)
            if is_wsl():
                # v6.3: WSL báo platform.system() == \"Linux\" nhưng không có
                # systemctl/pactl/xdg-open thật - chuyển tiếp sang Windows host.
                return _system_control_wsl(target)

            if target in commands_linux:
                if _run_first_available(commands_linux[target]):
                    safe_print(f"[THỰC THI] Lệnh hệ thống (Linux): {target}")
                    return True
                safe_print(f"[LỖI] Không tìm thấy công cụ phù hợp cho '{target}' trên máy Linux "
                      f"này (đã thử systemctl/shutdown/loginctl...). Môi trường desktop của "
                      f"bạn có thể cần 1 lệnh khác - hãy chỉnh trong action_system_control().")
                logger.warning("Không tìm thấy lệnh Linux khả dụng cho: %s", target)
                return False

            if target in volume_linux:
                if _run_first_available(volume_linux[target]):
                    safe_print(f"[THỰC THI] Điều chỉnh âm thanh (Linux): {target}")
                    return True
                safe_print("[LỖI] Không tìm thấy công cụ chỉnh âm lượng (đã thử wpctl, pactl, amixer) "
                      "trên máy này. Cài PipeWire (wpctl), PulseAudio (pactl) hoặc ALSA utils (amixer).")
                logger.warning("Không tìm thấy công cụ âm lượng Linux khả dụng cho: %s", target)
                return False

            if target == "screenshot":
                pictures_dir = os.path.join(HOME, "Pictures")
                os.makedirs(pictures_dir, exist_ok=True)
                path = os.path.join(pictures_dir,
                                    f"screenshot_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
                # v6.3: thêm spectacle (KDE Plasma), grim (Wayland/Sway) và
                # import (ImageMagick) - trước đây chỉ thử gnome-screenshot/scrot.
                if _run_first_available([
                        ["gnome-screenshot", "-f", path],
                        ["spectacle", "-bn", "-o", path],
                        ["scrot", path],
                        ["grim", path],
                        ["import", "-window", "root", path]]):
                    safe_print(f"[THỰC THI] Đã chụp màn hình: {path}")
                    return True
                safe_print("[LỖI] Không tìm thấy công cụ chụp màn hình (đã thử "
                           "gnome-screenshot, spectacle, scrot, grim, import).")
                return False

        safe_print(f"[BỎ QUA] Không hỗ trợ lệnh hệ thống '{target}' trên {SYSTEM}.")
        logger.warning("Không hỗ trợ lệnh hệ thống '%s' trên %s", target, SYSTEM)
        return False
    except Exception as e:
        safe_print(f"[LỖI] Không thực thi được lệnh hệ thống: {e}")
        logger.error("Không thực thi được lệnh hệ thống '%s': %s", target, e)
        return False


# ============================================================================
# 2B. HÀNH ĐỘNG "PHẢN HỒI HỘI THOẠI" (tìm kiếm, nhạc, nhắc nhở, thời tiết,
# giờ/ngày, tính toán, trò chuyện) - dùng respond() để có thể đọc bằng giọng nói
# ============================================================================
def action_search_web(target: str) -> bool:
    """Tìm kiếm từ khoá trên Google."""
    if not target or target == "unknown":
        respond("Bạn muốn tìm gì ạ?")
        return False
    url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(target)
    respond(f"Đang tìm kiếm {target}")
    logger.info("Tìm kiếm web: %s", target)
    _open_url(url)
    return True


def action_play_media(target: str) -> bool:
    """Phát nhạc / video: mở kết quả tìm kiếm trên YouTube."""
    query = target or "nhạc"
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(query)
    respond(f"Đang phát {query}")
    logger.info("Phát media: %s", query)
    _open_url(url)
    return True


def _format_number(value) -> str:
    """Format số cho dễ nghe: bỏ .0 thừa, giữ tối đa 4 số thập phân."""
    if value is None:
        return ""
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return f"{round(value, 4):g}"
    return str(value)


def action_calculate(target: str, data: dict = None) -> bool:
    """Đọc kết quả phép tính (đã được intent_model.py tính sẵn trong 'result')."""
    data = data or {}
    result = data.get("result")

    if result is None:
        try:
            from intent_model import parse_math_expression
            _, result = parse_math_expression(target or "")
        except Exception:
            result = None

    if result is None:
        respond(f"Xin lỗi, tôi chưa tính được phép tính {target}")
        return False

    respond(f"{target} bằng {_format_number(result)}")
    return True


def action_get_weather(target: str) -> bool:
    """Mở trang thời tiết cho địa điểm được yêu cầu."""
    location = target if target and target != "hôm nay" else ""
    query = f"thời tiết {location}".strip()
    url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(query)
    respond(f"Đang xem {query}")
    logger.info("Xem thời tiết: %s", query)
    _open_url(url)
    return True


WEEKDAYS_VI = ["thứ Hai", "thứ Ba", "thứ Tư", "thứ Năm",
               "thứ Sáu", "thứ Bảy", "Chủ nhật"]


def action_get_datetime(target: str) -> bool:
    """Trả lời giờ hiện tại hoặc ngày tháng hôm nay."""
    now = datetime.datetime.now()
    if target == "date":
        msg = (f"Hôm nay là {WEEKDAYS_VI[now.weekday()]}, "
               f"ngày {now.day} tháng {now.month} năm {now.year}.")
    else:
        msg = f"Bây giờ là {now.hour} giờ {now.minute} phút."
    respond(msg)
    return True


def action_chitchat(target: str) -> bool:
    """Trả lời câu trò chuyện vặt / ngoài phạm vi điều khiển máy (không thực
    thi lệnh nào trên máy - đây là "lưới an toàn" cho mọi câu không khớp
    intent hành động nào khác)."""
    text = (target or "").lower()
    for pattern, replies in CHITCHAT_REPLIES:
        if re.search(pattern, text):
            respond(random.choice(replies))
            return True
    respond("Tôi chưa hiểu ý bạn lắm, bạn nói rõ hơn giúp tôi nhé.")
    return True


def _save_reminders() -> None:
    """Ghi các nhắc nhở đang chờ ra đĩa (v6)."""
    try:
        data = [{"id": item.get("id"), "task": item["task"], "at": item["at"].isoformat()}
                for item in ACTIVE_REMINDERS]
        with open(REMINDERS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except (OSError, KeyError, AttributeError) as e:
        logger.warning("Không lưu được danh sách nhắc nhở: %s", e)


def _schedule_reminder(task: str, run_at, persist: bool = True):
    """Hẹn giờ 1 lời nhắc và ghi vào danh sách đang chờ. Trả về id hoặc None."""
    delay = (run_at - datetime.datetime.now()).total_seconds()
    if delay <= 0:
        return None
    # v6.2: hậu tố ngẫu nhiên thay vì số thứ tự - trước đây thêm/xoá nhắc
    # nhở trong cùng 1 giây có thể tạo 2 id GIỐNG NHAU, khiến
    # _fire_reminder() / cancel_reminder() gỡ nhầm mục.
    reminder_id = "{0}-{1}".format(run_at.strftime("%Y%m%d%H%M%S"), uuid.uuid4().hex[:6])
    timer = threading.Timer(delay, _fire_reminder, args=[task, reminder_id])
    timer.daemon = True
    timer.start()
    ACTIVE_REMINDERS.append({"id": reminder_id, "task": task, "at": run_at, "timer": timer})
    if persist:
        _save_reminders()
    return reminder_id


def restore_reminders() -> int:
    """Nạp lại các nhắc nhở CÒN HẠN sau khi khởi động lại chương trình (v6).

    Trước đây mọi lời nhắc chỉ sống trong RAM: lỡ thoát chương trình (hoặc
    máy tự khởi động lại) là mất sạch, không báo cho người dùng biết.
    """
    if not os.path.exists(REMINDERS_PATH):
        return 0
    try:
        with open(REMINDERS_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError) as e:
        logger.warning("Không đọc được reminders.json: %s", e)
        return 0

    restored = 0
    for item in data if isinstance(data, list) else []:
        try:
            run_at = datetime.datetime.fromisoformat(str(item.get("at")))
        except (TypeError, ValueError):
            continue
        task = str(item.get("task") or "báo thức")
        if _schedule_reminder(task, run_at, persist=False):
            restored += 1
    _save_reminders()
    if restored:
        logger.info("Đã khôi phục %d nhắc nhở còn hạn", restored)
    return restored


def cancel_reminder(keyword: str = None):
    """Huỷ nhắc nhở theo từ khoá (hoặc TẤT CẢ nếu không truyền gì) - mới ở v6."""
    key = strip_diacritics((keyword or "").strip().lower())
    removed = []
    for item in list(ACTIVE_REMINDERS):
        if key and key not in strip_diacritics(item["task"].lower()) and key != item.get("id"):
            continue
        try:
            item["timer"].cancel()
        except AttributeError:
            pass
        ACTIVE_REMINDERS.remove(item)
        removed.append(item)
    if removed:
        _save_reminders()
    return removed


def _fire_reminder(task: str, reminder_id: str = None) -> None:
    """Hàm được gọi khi đến giờ nhắc (chạy trong thread nền)."""
    # v6: tự gỡ khỏi danh sách sau khi đã kêu. Trước đây nhắc nhở đã xong vẫn
    # nằm mãi trong ACTIVE_REMINDERS -> lệnh "nhac nho" liệt kê cả mục đã qua
    # và danh sách phình to dần theo thời gian chạy.
    if reminder_id is not None:
        for item in list(ACTIVE_REMINDERS):
            if item.get("id") == reminder_id:
                ACTIVE_REMINDERS.remove(item)
        _save_reminders()
    respond(f"Đến giờ rồi. Nhắc bạn: {task}")
    try:
        if SYSTEM == "Windows":
            safe = task.replace("'", "''")
            ps = ("Add-Type -AssemblyName PresentationFramework; "
                  f"[System.Windows.MessageBox]::Show('{safe}','Nhắc nhở')")
            subprocess.Popen(["powershell", "-NoProfile", "-Command", ps])
        elif SYSTEM == "Darwin":
            safe = task.replace('"', '\\"')
            subprocess.Popen(["osascript", "-e",
                              f'display notification "{safe}" with title "Nhắc nhở"'])
        else:
            _run_first_available([["notify-send", "Nhắc nhở", task]])
    except Exception as e:
        logger.warning("Không hiện được popup nhắc nhở: %s", e)


def action_set_reminder(target: str, data: dict = None) -> bool:
    """
    Đặt nhắc nhở / báo thức bằng threading.Timer (chạy nền trong chương trình).

    Lưu ý: nhắc nhở chỉ sống khi chương trình còn chạy.
    """
    time_info = (data or {}).get("time") or {"type": None}
    task = target or "báo thức"
    now = datetime.datetime.now()

    if time_info.get("type") == "delay":
        minutes = time_info.get("minutes", 5)
        run_at = now + datetime.timedelta(minutes=minutes)
    elif time_info.get("type") == "clock":
        # Kẹp về khoảng hợp lệ (0-23 / 0-59) trước khi .replace() - phòng
        # trường hợp tầng NLU trích xuất giờ/phút bất thường từ 1 câu nói lạ
        # (vd hiểu nhầm "20h" thành hour=20 giờ + thêm gì đó thành 25...).
        # .replace() ném ValueError ngay lập tức với giá trị ngoài khoảng,
        # và trước đây lỗi này sẽ làm sập cả chương trình (nay đã có thêm
        # lưới an toàn ở main.py, nhưng chặn tại nguồn vẫn tốt hơn).
        hour = max(0, min(23, time_info.get("hour", 7)))
        minute = max(0, min(59, time_info.get("minute", 0)))
        run_at = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        # v6: hiểu thêm "sáng mai / ngày mai" (day_offset từ parse_time_expression)
        run_at += datetime.timedelta(days=max(0, int(time_info.get("day_offset") or 0)))
        if run_at <= now:
            run_at += datetime.timedelta(days=1)   # sang ngày mai
    else:
        respond("Bạn muốn tôi nhắc vào lúc nào ạ?")
        return False

    delay = (run_at - now).total_seconds()
    if delay <= 0:
        respond("Thời điểm bạn đưa đã qua mất rồi.")
        return False

    _schedule_reminder(task, run_at)
    logger.info("Đặt nhắc nhở: %s lúc %s", task, run_at)

    respond(f"Đã đặt nhắc nhở {task} vào lúc {run_at.hour} giờ {run_at.minute} phút.")
    return True


def action_unknown(_target: str) -> bool:
    """Dự phòng cho nhãn intent lạ không có trong HANDLERS (không nên xảy ra
    trong điều kiện bình thường vì bộ phân loại chỉ trả về 1 trong 11 nhãn
    đã huấn luyện)."""
    safe_print("Xin lỗi, tôi chỉ hỗ trợ mở web / ứng dụng / file, điều khiển hệ "
          "thống, tìm kiếm, phát nhạc, đặt nhắc nhở, xem thời tiết/giờ và "
          "tính toán. Bạn thử nói cụ thể hơn nhé.")
    return False


# ============================================================================
# 3. HÀM CHÍNH: execute_command
# ============================================================================
HANDLERS = {
    "open_website": action_open_website,
    "open_app": action_open_app,
    "open_file": action_open_file,
    "system_control": action_system_control,
    "search_web": action_search_web,
    "play_media": action_play_media,
    "set_reminder": action_set_reminder,
    "get_weather": action_get_weather,
    "get_datetime": action_get_datetime,
    "calculate": action_calculate,
    "chitchat": action_chitchat,
}

# Các handler cần nguyên cả intent_json (data) chứ không chỉ target, vì cần
# thêm thông tin phụ ("time" cho set_reminder, "result" cho calculate).
_HANDLERS_WITH_DATA = {"set_reminder", "calculate"}


def execute_command(intent_json) -> bool:
    """
    Nhận JSON (dict hoặc chuỗi) từ mô hình và thực thi hành động tương ứng.

    Ví dụ:
        execute_command({"intent": "open_website", "target": "google", "confidence": 0.93})
    """
    if isinstance(intent_json, str):
        try:
            intent_json = json.loads(intent_json)
        except json.JSONDecodeError:
            safe_print("[LỖI] Đầu vào không phải JSON hợp lệ.")
            return False

    intent = intent_json.get("intent")
    # LƯU Ý (vá lỗi giữ lại từ bản trước): KHÔNG .lower() toàn bộ target ở
    # đây - _best_match() đã tự hạ chữ thường RIÊNG khi so khớp với config,
    # nhưng hạ thường ở đây sẽ phá hoa/thường có Ý NGHĨA khi target không
    # khớp config và được dùng trực tiếp làm URL/đường dẫn (ID video YouTube,
    # tên file trên hệ thống phân biệt hoa/thường).
    target = (intent_json.get("target") or "").strip()
    confidence = float(intent_json.get("confidence", 1.0))

    handler = HANDLERS.get(intent)
    if handler is None:
        safe_print(f"[TỪ CHỐI] Không hiểu ý định: {intent}")
        logger.warning("Không hiểu ý định: %s", intent)
        return action_unknown(target)

    if confidence < CONFIDENCE_THRESHOLD:
        safe_print(f"[TỪ CHỐI] Độ tự tin quá thấp ({confidence:.2f}). Bạn nói rõ hơn giúp tôi nhé.")
        logger.info("Từ chối vì độ tự tin thấp: %.2f < %.2f", confidence, CONFIDENCE_THRESHOLD)
        return False

    if intent in _HANDLERS_WITH_DATA:
        return handler(target, intent_json)
    return handler(target)


# ============================================================================
# 4. TEST NHANH MÔ-ĐUN
# ============================================================================
if __name__ == "__main__":
    setup_console()
    demo = {"intent": "open_website", "target": "google", "confidence": 0.95}
    safe_print(f"Demo: {demo}")
    execute_command(demo)
