# Trợ lý ảo tiếng Việt (v6.4)

Trợ lý ảo chạy bằng dòng lệnh, hiểu tiếng Việt **có dấu lẫn không dấu**, nhận diện
11 nhóm ý định và thực thi lệnh thật trên Windows (kể cả Windows 7), macOS, Linux.

> **v6.2**: sửa lỗi phân tích giờ nghiêm trọng ("nhắc tôi họp lúc 9 giờ" từng
> thành 21h), hiểu số viết bằng chữ, tách đa-lệnh khi gõ không dấu — xem
> **CHANGELOG.md**.
>
> **v6.3**: hỗ trợ WSL thật sự (chuyển tiếp lệnh sang Windows host), phân
> biệt Windows 10/11, Linux hiện đại (PipeWire/KDE/Wayland), lệnh mới
> `he thong` / `python main.py --sysinfo` để xem máy hỗ trợ tính năng nào.

## Điểm nổi bật

- **11 ý định**: mở web, mở app, mở file, điều khiển hệ thống (tắt máy, âm lượng…),
  tìm kiếm, phát nhạc/video, nhắc nhở, thời tiết, xem giờ/ngày, tính toán, chit-chat.
- **Không cần thư viện ngoài**: bản v6 có sẵn bộ phân loại Naive Bayes n-gram ký tự
  viết bằng Python thuần (`lite_model.py`), huấn luyện < 1 giây, chính xác ~97–98%.
  Nếu cài `scikit-learn` sẽ tự dùng pipeline TF-IDF; nếu huấn luyện PhoBERT sẽ tự
  dùng PhoBERT (chính xác nhất).
- **Thông minh đời thường**: gõ không dấu, viết tắt/teencode, sai chính tả nhẹ,
  nhiều lệnh trong 1 câu (kể cả khi gõ không dấu), nhớ ngữ cảnh hội thoại
  ("đóng nó lại"), học từ phản hồi, hiểu số viết bằng chữ
  ("mười lăm cộng hai mươi bảy", "nhắc tôi họp lúc bảy giờ sáng").
- **An toàn**: không bao giờ chạy chuỗi người dùng qua shell, whitelist app/web/file
  trong `config.json`, xác nhận trước hành động nguy hiểm, chặn file thực thi,
  chặn "bom luỹ thừa" trong máy tính, giữ nguyên URL (dấu `? = & #`, hoa/thường).
- **Nhắc nhở bền bỉ**: tự lưu ra `reminders.json` và khôi phục khi mở lại app;
  hiểu "3h30", "3 giờ rưỡi", "8 giờ kém 15", "11 giờ đêm", "7 giờ sáng mai"…

## Cài đặt & chạy

```bash
python main.py            # chạy ngay, không cần cài gì thêm
```

Tuỳ chọn (nâng cao độ chính xác / giọng nói):

```bash
pip install -r requirements.txt   # scikit-learn, pyttsx3, SpeechRecognition...
```

## Cách dùng

```bash
python main.py                          # chế độ hỏi-đáp (gõ tay hoặc nói)
python main.py --once "mở youtube"      # chạy đúng 1 lệnh rồi thoát
python main.py --once "mấy giờ" --json  # xuất JSON cho script khác dùng
python main.py --version                # phiên bản + loại model đang dùng
python main.py --dry-run                # chỉ phân tích, không thực thi
```

Lệnh điều khiển trong phiên: `mic`, `voice`, `test`, `nhac nho`, `huy nhac [từ khoá]`,
`nap lai`, `day <câu> = <intent>`, `quen`, `help`, `thoat`.

Chi tiết đầy đủ: xem **HUONG_DAN_SU_DUNG.txt**.

## Cấu trúc

| File | Vai trò |
|---|---|
| `main.py` | Vòng lặp chính + CLI (`--once`, `--json`, `--version`) |
| `nlu_advanced.py` | Tầng hiểu ý: phục hồi dấu, tách lệnh, ngữ cảnh, 4 trạng thái |
| `intent_model.py` | Pipeline TF-IDF + trích xuất thực thể + giờ giấc + tính toán |
| `lite_model.py` | **v6** — bộ phân loại thuần Python, không cần scikit-learn |
| `executor.py` | Thực thi lệnh an toàn trên Windows/macOS/Linux |
| `dataset.py` | ~1.530 câu mẫu (có dấu + biến thể không dấu), 11 nhãn |
| `config.json` | Whitelist web/app/file, ngưỡng độ tự tin, hành động nguy hiểm |
| `stt.py`, `tts.py` | Giọng nói vào/ra (tuỳ chọn) |
| `run_tests.py` | **v6** — chạy test không cần cài pytest |
| `tests/` | 220 unit test |

## Kiểm thử

```bash
python run_tests.py        # không cần cài thêm gì
pytest tests/ -v           # nếu đã cài pytest
```

## Tương thích

Python 3.8+ (Windows 7 dùng Python 3.8.x), Windows 8/10/11, macOS, Linux —
kể cả **WSL** (tự chuyển tiếp lệnh sang Windows host). Chạy
`python main.py --sysinfo` để xem máy bạn hỗ trợ tính năng nào.
